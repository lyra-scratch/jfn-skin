# JFN Cams - Chaturbate in Kodi (stage 1: browse, play, login, favorites)
# Built for Chad / Jersey Fresh Network. Stdlib only.
import sys, os, re, json
from urllib.parse import parse_qsl, urlencode, quote_plus, quote
from urllib.request import Request, build_opener, HTTPCookieProcessor
from http.cookiejar import MozillaCookieJar

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
BASE = sys.argv[0]
try:
    HANDLE = int(sys.argv[1])
except Exception:
    HANDLE = -1
PARAMS = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}

SITE = 'https://chaturbate.com'
API = SITE + '/api/ts/roomlist/room-list/'
UA_BROWSER = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
UA_IPAD = 'Mozilla/5.0 (iPad; CPU OS 8_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B410 Safari/600.1.4'
LIMIT = 60

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
if not os.path.isdir(PROFILE):
    os.makedirs(PROFILE)
COOKIE_FILE = os.path.join(PROFILE, 'cookies.txt')
FAV_FILE = os.path.join(PROFILE, 'favorites.json')

_cj = MozillaCookieJar(COOKIE_FILE)
if os.path.exists(COOKIE_FILE):
    try:
        _cj.load(ignore_discard=True, ignore_expires=True)
    except Exception:
        pass
_opener = build_opener(HTTPCookieProcessor(_cj))


def save_cookies():
    try:
        _cj.save(ignore_discard=True, ignore_expires=True)
    except Exception:
        pass


def http(url, data=None, headers=None, ua=UA_BROWSER, timeout=30):
    hdrs = {'User-Agent': ua, 'Accept-Language': 'en-US,en;q=0.9'}
    if headers:
        hdrs.update(headers)
    body = urlencode(data).encode('utf-8') if data is not None else None
    req = Request(url, data=body, headers=hdrs)
    with _opener.open(req, timeout=timeout) as resp:
        raw = resp.read()
    save_cookies()
    return raw.decode('utf-8', 'replace')


def notify(msg, heading='JFN Cams', ms=4500):
    xbmcgui.Dialog().notification(heading, msg, xbmcgui.NOTIFICATION_INFO, ms)


# ---------------- local favorites ----------------

def load_favs():
    if os.path.exists(FAV_FILE):
        try:
            return json.load(open(FAV_FILE, encoding='utf-8'))
        except Exception:
            return []
    return []


def save_favs(favs):
    with open(FAV_FILE, 'w', encoding='utf-8') as f:
        json.dump(favs, f)


def fav_slugs():
    return [f.get('slug') for f in load_favs()]


# ---------------- login ----------------

def has_session_cookie():
    for c in _cj:
        if c.name == 'sessionid' and 'chaturbate.com' in c.domain and c.value:
            return True
    return False


def logged_in_live():
    """True if the site treats our session as logged in (checks the followed page)."""
    try:
        html = http(SITE + '/followed-cams/')
    except Exception:
        return False
    return '>Chaturbate Login</h1>' not in html


def do_login():
    """Log in with the credentials from the add-on settings. Returns (ok, message)."""
    user = ADDON.getSetting('username').strip()
    pw = ADDON.getSetting('password')
    if not user or not pw:
        return False, 'Set your username and password in the add-on settings first'
    login_url = SITE + '/auth/login/?next=/followed-cams/'
    try:
        html = http(login_url)
    except Exception as e:
        return False, 'Could not reach the login page: %s' % e
    m = re.search(r'"csrfmiddlewaretoken"\s+value="([^"]+)"', html)
    if not m:
        return False, 'Login form changed on the site - token not found'
    post = {'next': '/followed-cams/', 'csrfmiddlewaretoken': m.group(1),
            'username': user, 'password': pw, 'rememberme': 'on'}
    try:
        resp = http(login_url, data=post, headers={'Referer': login_url})
    except Exception as e:
        return False, 'Login request failed: %s' % e
    if '>Chaturbate Login</h1>' in resp:
        if 'captcha' in resp.lower() or 'recaptcha' in resp.lower():
            return False, 'The site demanded a captcha. Log in once on the site, then try again'
        return False, 'Login failed - check your username and password'
    if has_session_cookie():
        return True, 'Logged in as %s' % user
    return False, 'Login did not stick - no session was set'


def ensure_login():
    if has_session_cookie() and logged_in_live():
        return True
    ok, msg = do_login()
    if ok:
        notify(msg)
        return True
    notify(msg)
    if 'settings first' in msg:
        ADDON.openSettings()
    return False


def do_logout():
    try:
        http(SITE + '/auth/logout/')
    except Exception:
        pass
    _cj.clear()
    save_cookies()
    notify('Logged out')
    xbmc.executebuiltin('Container.Refresh')


# ---------------- site data ----------------

def api_rooms(query):
    url = API + '?' + query
    raw = http(url)
    data = json.loads(raw)
    return data.get('rooms', []), data.get('total_count', 0)


def cookie_header():
    """Serialize the session jar for the player: the stream CDN checks the
    site cookies AND the exact user agent, so both must ride along."""
    parts = []
    for c in _cj:
        if c.value and re.match(r'^[A-Za-z0-9_\-\.]+$', c.name or '') and \
           re.match(r'^[A-Za-z0-9_\-\.~%+/=]+$', c.value):
            parts.append('%s=%s' % (c.name, c.value))
    return '; '.join(parts)


def resolve_stream(slug):
    """Return (m3u8_url, room_status)."""
    url = SITE + '/get_edge_hls_url_ajax/'
    hdrs = {'X-Requested-With': 'XMLHttpRequest',
            'Referer': SITE + '/' + slug + '/',
            'Content-Type': 'application/x-www-form-urlencoded'}
    raw = http(url, data={'room_slug': slug, 'bandwidth': 'high'}, headers=hdrs, ua=UA_IPAD)
    data = json.loads(raw)
    return data.get('url'), data.get('room_status', 'unknown')


def follow_action(slug, follow=True):
    if not ensure_login():
        return
    path = '/follow/follow/' if follow else '/follow/unfollow/'
    url = SITE + path + slug + '/'
    try:
        html = http(url)
        m = re.search(r'"csrfmiddlewaretoken"\s+value="([^"]+)"', html)
        if not m:
            notify('Follow failed - token not found')
            return
        resp = http(url, data={'csrfmiddlewaretoken': m.group(1)},
                    headers={'Referer': SITE + '/'})
        want = '"following": true' if follow else '"following": false'
        if want in resp:
            notify(('Now following ' if follow else 'Unfollowed ') + slug)
            xbmc.executebuiltin('Container.Refresh')
        else:
            notify('The site did not confirm the change')
    except Exception as e:
        notify('Follow failed: %s' % e)


# ---------------- rendering ----------------

def plugin_url(params):
    return BASE + '?' + urlencode(params)


def add_room(room, favs, folder_context=False):
    slug = room.get('username', '')
    if not slug:
        return
    img = room.get('img', '')
    viewers = room.get('num_users', 0)
    followers = room.get('num_followers', 0)
    subject = (room.get('room_subject') or room.get('subject') or '').strip()
    loc = room.get('location') or room.get('country') or ''
    plot = subject
    meta = 'Viewers: %s   Followers: %s' % (viewers, followers)
    if loc:
        meta += '   ' + loc
    plot = (plot + '\n' + meta) if plot else meta
    tags = room.get('tags') or []
    if tags:
        plot += '\n' + ' '.join('#' + t for t in tags[:8])
    label = slug
    status = room.get('current_show', 'public')
    playable = status in ('public',)
    li = xbmcgui.ListItem(label=label)
    li.setArt({'thumb': img, 'icon': img, 'fanart': img})
    li.setInfo('video', {'title': label, 'plot': plot, 'mediatype': 'video'})
    menu = []
    if room.get('is_following'):
        menu.append(('Unfollow ' + slug, 'RunPlugin(%s)' % plugin_url({'mode': 'unfollow', 'slug': slug})))
    else:
        menu.append(('Follow ' + slug, 'RunPlugin(%s)' % plugin_url({'mode': 'follow', 'slug': slug})))
    if slug in favs:
        menu.append(('Remove from My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_del', 'slug': slug})))
    else:
        menu.append(('Add to My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_add', 'slug': slug, 'img': img})))
    li.addContextMenuItems(menu)
    if playable:
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'play', 'slug': slug}), li, False)
    else:
        li.setLabel(label + '  [' + status + ']')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'offline', 'slug': slug, 'status': status}), li, False)


def list_rooms(query, title):
    xbmcplugin.setContent(HANDLE, 'videos')
    try:
        rooms, total = api_rooms(query)
    except Exception as e:
        notify('Could not load rooms: %s' % e)
        rooms, total = [], 0
    favs = fav_slugs()
    for room in rooms:
        add_room(room, favs)
    # next page
    q = dict(parse_qsl(query))
    offset = int(q.get('offset', '0'))
    if rooms and offset + len(rooms) < total:
        q['offset'] = str(offset + int(q.get('limit', str(LIMIT))))
        li = xbmcgui.ListItem(label='Next page >>')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'list', 'query': urlencode(q), 'title': title}), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def root_menu():
    xbmcplugin.setContent(HANDLE, 'files')
    items = [
        ('Featured', {'mode': 'list', 'query': 'limit=%d&offset=0' % LIMIT, 'title': 'Featured'}),
        ('Female', {'mode': 'list', 'query': 'genders=f&limit=%d&offset=0' % LIMIT, 'title': 'Female'}),
        ('Male', {'mode': 'list', 'query': 'genders=m&limit=%d&offset=0' % LIMIT, 'title': 'Male'}),
        ('Couples', {'mode': 'list', 'query': 'genders=c&limit=%d&offset=0' % LIMIT, 'title': 'Couples'}),
        ('Trans', {'mode': 'list', 'query': 'genders=t&limit=%d&offset=0' % LIMIT, 'title': 'Trans'}),
        ('New cams', {'mode': 'list', 'query': 'new_cams=true&limit=%d&offset=0' % LIMIT, 'title': 'New cams'}),
        ('Followed cams (online)', {'mode': 'followed', 'offline': 'false'}),
        ('Followed cams (offline)', {'mode': 'followed', 'offline': 'true'}),
        ('My Favorites', {'mode': 'favorites'}),
        ('Go to room by name...', {'mode': 'goto'}),
    ]
    if has_session_cookie():
        items.append(('Log out (%s)' % ADDON.getSetting('username'), {'mode': 'logout'}))
    else:
        items.append(('Log in', {'mode': 'login'}))
    for label, params in items:
        li = xbmcgui.ListItem(label=label)
        folder = params.get('mode') in ('list', 'followed', 'favorites')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, folder)
    xbmcplugin.endOfDirectory(HANDLE)


def followed_view(offline):
    if not ensure_login():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    q = 'enable_recommendations=true&follow=true&limit=100&offline=%s&offset=0' % offline
    list_rooms(q, 'Followed')


def favorites_view():
    xbmcplugin.setContent(HANDLE, 'videos')
    favs = load_favs()
    if not favs:
        li = xbmcgui.ListItem(label='No favorites yet - open a room list and use the context menu on a room')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    for fav in favs:
        slug = fav.get('slug', '')
        img = fav.get('img', '')
        if not slug:
            continue
        status = 'unknown'
        try:
            _, status = resolve_stream(slug)
        except Exception:
            status = 'unknown'
        li = xbmcgui.ListItem(label=slug + '  [' + status + ']')
        li.setArt({'thumb': img, 'icon': img, 'fanart': img})
        li.setInfo('video', {'title': slug, 'plot': 'Status: ' + status, 'mediatype': 'video'})
        menu = [('Remove from My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_del', 'slug': slug}))]
        li.addContextMenuItems(menu)
        if status == 'public':
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'play', 'slug': slug}), li, False)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'offline', 'slug': slug, 'status': status}), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def play(slug):
    try:
        url, status = resolve_stream(slug)
    except Exception as e:
        notify('Could not resolve the stream: %s' % e)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if status == 'public' and url:
        hdr = '|User-Agent=' + UA_IPAD
        ch = cookie_header()
        if ch:
            hdr += '&Cookie=' + ch
        li = xbmcgui.ListItem(path=url + hdr)
        li.setInfo('video', {'title': slug})
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        notify('%s is not in a public show right now (%s)' % (slug, status))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


# ---------------- routing ----------------

def main():
    mode = PARAMS.get('mode', '')
    if mode == 'list':
        list_rooms(PARAMS.get('query', 'limit=%d&offset=0' % LIMIT), PARAMS.get('title', ''))
    elif mode == 'followed':
        followed_view(PARAMS.get('offline', 'false'))
    elif mode == 'favorites':
        favorites_view()
    elif mode == 'play':
        play(PARAMS.get('slug', ''))
    elif mode == 'offline':
        notify('%s is %s right now' % (PARAMS.get('slug', ''), PARAMS.get('status', 'offline')))
    elif mode == 'goto':
        kb = xbmcgui.Dialog().input('Room name', type=xbmcgui.INPUT_ALPHANUM)
        if kb:
            xbmc.executebuiltin('PlayMedia(%s)' % plugin_url({'mode': 'play', 'slug': kb.strip().lower()}))
    elif mode == 'login':
        ok, msg = (True, 'Already logged in') if (has_session_cookie() and logged_in_live()) else do_login()
        notify(msg)
        if not ok and 'settings first' in msg:
            ADDON.openSettings()
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'logout':
        do_logout()
    elif mode == 'follow':
        follow_action(PARAMS.get('slug', ''), True)
    elif mode == 'unfollow':
        follow_action(PARAMS.get('slug', ''), False)
    elif mode == 'fav_add':
        favs = load_favs()
        slug = PARAMS.get('slug', '')
        if slug and slug not in fav_slugs():
            favs.append({'slug': slug, 'img': PARAMS.get('img', '')})
            save_favs(favs)
            notify('Added ' + slug + ' to My Favorites')
    elif mode == 'fav_del':
        slug = PARAMS.get('slug', '')
        save_favs([f for f in load_favs() if f.get('slug') != slug])
        notify('Removed ' + slug + ' from My Favorites')
        xbmc.executebuiltin('Container.Refresh')
    else:
        root_menu()


if __name__ == '__main__':
    main()
