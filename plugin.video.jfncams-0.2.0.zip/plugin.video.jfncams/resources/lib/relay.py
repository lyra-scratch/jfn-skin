# Local relay for JFN Cams.
#
# Why this exists (measured 2026-11-13): the site's stream URLs carry a
# single-use token. The FIRST fetch of a playlist URL returns 200; every later
# fetch of the same URL returns 403, no matter the cookies or user agent.
# Kodi's player touches a stream URL several times (stat, open, playlist
# reloads), so direct playback can never work. The relay is the only client
# that talks to the CDN: it resolves a FRESH stream URL for every playlist
# load, fetches each playlist/segment/part exactly once, caches segment bytes,
# and serves Kodi a plain local HLS feed on 127.0.0.1.
import re, threading
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote, urljoin

import camsite

PORT = 57711
BASE_PREFIX = 'http://127.0.0.1:%d' % PORT
CACHE_MAX_ITEMS = 80
CACHE_MAX_BYTES = 64 * 1024 * 1024

_stats = {'resolves': 0, 'playlist_fetches': 0, 'seg_fetches': 0, 'cache_hits': 0}
_stats_lock = threading.Lock()


def _bump(key):
    with _stats_lock:
        _stats[key] += 1


def stats():
    with _stats_lock:
        return dict(_stats)


class SegCache:
    def __init__(self):
        self._d = OrderedDict()
        self._bytes = 0
        self._lock = threading.Lock()

    def get(self, url):
        with self._lock:
            if url in self._d:
                self._d.move_to_end(url)
                _bump('cache_hits')
                return self._d[url]
        return None

    def put(self, url, body):
        with self._lock:
            if url in self._d:
                self._bytes -= len(self._d[url])
            self._d[url] = body
            self._bytes += len(body)
            while len(self._d) > CACHE_MAX_ITEMS or self._bytes > CACHE_MAX_BYTES:
                _, old = self._d.popitem(last=False)
                self._bytes -= len(old)


CACHE = SegCache()

_URI_ATTR = re.compile(r'URI="([^"]+)"')
_BARE_URI = re.compile(r'^(?!#)(\S+)$')


def rewrite_playlist(text, base_url, prefix):
    """Point every object in an HLS playlist back at this relay.
    prefix is '' when the handler serves at root."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append(line)
            continue
        if s.startswith('#'):
            def sub(m):
                u = urljoin(base_url, m.group(1))
                if u.split('?')[0].endswith('.m3u8'):
                    return 'URI="%s/pl?u=%s"' % (prefix, quote(u, safe=''))
                return 'URI="%s/seg?u=%s"' % (prefix, quote(u, safe=''))
            out.append(_URI_ATTR.sub(sub, line))
        else:
            u = urljoin(base_url, s)
            if u.split('?')[0].endswith('.m3u8'):
                out.append('%s/pl?u=%s' % (prefix, quote(u, safe='')))
            else:
                out.append('%s/seg?u=%s' % (prefix, quote(u, safe='')))
    return '\n'.join(out) + '\n'


def fetch_playlist_by_url(url):
    """Fetch one playlist URL once and return it rewritten."""
    status, body = camsite.http_status(url)
    _bump('playlist_fetches')
    if status != 200:
        return status, None
    text = body.decode('utf-8', 'replace')
    return 200, rewrite_playlist(text, url, BASE_PREFIX)


def fetch_playlist_by_slug(slug):
    """Resolve a FRESH stream URL (single-use token) and fetch its playlist."""
    url, room_status = camsite.resolve_stream(slug)
    _bump('resolves')
    if not url or room_status != 'public':
        return 404, None
    return fetch_playlist_by_url(url)


def fetch_segment(url):
    body = CACHE.get(url)
    if body is not None:
        return 200, body
    status, body = camsite.http_status(url)
    _bump('seg_fetches')
    if status == 200:
        CACHE.put(url, body)
    return status, body


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    def _send(self, status, body, ctype='application/octet-stream'):
        if body is None:
            body = b''
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def do_HEAD(self):
        self._route()

    def do_GET(self):
        self._route()

    def _route(self):
        try:
            p = urlparse(self.path)
            q = parse_qs(p.query)
            if p.path.startswith('/play/') and p.path.endswith('.m3u8'):
                slug = p.path[len('/play/'):-len('.m3u8')]
                status, text = fetch_playlist_by_slug(slug)
                self._send(status, text.encode('utf-8') if text else None,
                           'application/vnd.apple.mpegurl')
            elif p.path == '/pl':
                status, text = fetch_playlist_by_url(q.get('u', [''])[0])
                self._send(status, text.encode('utf-8') if text else None,
                           'application/vnd.apple.mpegurl')
            elif p.path == '/seg':
                status, body = fetch_segment(q.get('u', [''])[0])
                ctype = 'video/mp2t'
                self._send(status, body, ctype)
            elif p.path == '/ping':
                self._send(200, b'ok', 'text/plain')
            elif p.path == '/stats':
                import json
                self._send(200, json.dumps(stats()).encode('utf-8'), 'application/json')
            else:
                self._send(404, b'not found', 'text/plain')
        except Exception:
            try:
                self._send(500, b'error', 'text/plain')
            except Exception:
                pass


def make_server(port=PORT):
    global BASE_PREFIX
    BASE_PREFIX = 'http://127.0.0.1:%d' % port
    return ThreadingHTTPServer(('127.0.0.1', port), Handler)


def play_url(slug, port=PORT):
    return 'http://127.0.0.1:%d/play/%s.m3u8' % (port, slug)
