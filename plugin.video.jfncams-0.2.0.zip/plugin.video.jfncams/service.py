# JFN Cams service: runs the local stream relay and the online alerts.
import os, sys, json, time

import xbmc, xbmcaddon, xbmcgui, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_DIR, 'resources', 'lib'))

import camsite
import relay

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
camsite.init(PROFILE)

STATE_FILE = os.path.join(PROFILE, 'alerts_state.json')


def _setting(key):
    try:
        return ADDON.getSetting(key)
    except Exception:
        return ''


def _load_state():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_state(state):
    try:
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f)
    except Exception:
        pass


def _fav_slugs():
    try:
        with open(os.path.join(PROFILE, 'favorites.json'), encoding='utf-8') as f:
            return [x.get('slug') for x in json.load(f) if x.get('slug')]
    except Exception:
        return []


def check_alerts(state):
    """One poll cycle. Returns the updated baseline set of online slugs."""
    online = set()
    if not camsite.has_session_cookie():
        return state.get('online', [])
    try:
        rooms, _ = camsite.api_rooms(camsite.followed_query(False))
        online |= {r.get('username') for r in rooms if r.get('username')}
    except Exception:
        return state.get('online', [])
    favs = _fav_slugs()
    if favs and len(favs) <= 20:
        for slug in favs:
            if slug in online:
                continue
            try:
                _, status = camsite.resolve_stream(slug)
                if status == 'public':
                    online.add(slug)
            except Exception:
                pass
    prev = set(state.get('online', []))
    if state.get('primed'):
        for slug in sorted(online - prev):
            xbmcgui.Dialog().notification('JFN Cams', '%s is online now' % slug,
                                          xbmcgui.NOTIFICATION_INFO, 6000)
    state['online'] = sorted(online)
    state['primed'] = True
    _save_state(state)
    return state['online']


def main():
    server = relay.make_server()
    import threading
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    xbmc.log('JFN Cams relay listening on 127.0.0.1:%d' % relay.PORT, xbmc.LOGINFO)

    monitor = xbmc.Monitor()
    state = _load_state()
    last_check = 0.0
    while not monitor.abortRequested():
        if _setting('alerts_enable') == 'true':
            try:
                minutes = int(_setting('alerts_minutes') or '10')
            except Exception:
                minutes = 10
            if time.time() - last_check >= max(2, minutes) * 60:
                last_check = time.time()
                try:
                    check_alerts(state)
                except Exception:
                    pass
        if monitor.waitForAbort(5):
            break
    try:
        server.shutdown()
    except Exception:
        pass


if __name__ == '__main__':
    main()
