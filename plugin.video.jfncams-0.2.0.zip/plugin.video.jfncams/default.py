# JFN Cams 0.2.0 - browse, filters, login, favorites, history, top cams,
# and playback through the local relay (see resources/lib/relay.py for why).
# Stdlib only.
import sys, os, json, time
from urllib.parse import parse_qsl, urlencode, quote
from urllib.request import urlopen

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_DIR, 'resources', 'lib'))

import camsite
import relay as relaymod

BASE = sys.argv[0]
try:
    HANDLE = int(sys.argv[1])
except Exception:
    HANDLE = -1
PARAMS = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}

LIMIT = 60
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
camsite.init(PROFILE)
FAV_FILE = os.path.join(PROFILE, 'favorites.json')
HIST_FILE = os.path.join(PROFILE, 'history.json')
FILTER_FILE = os.path.join(PROFILE, 'filters.json')

REGIONS = [('', 'Any region'), ('NA', 'North America'), ('SA', 'South America'),
           ('ER', 'Europe / Russia'), ('AS', 'Asia'), ('O', 'Other')]
AGES = [('', 'Any age'), ('18-19', '18-19'), ('20-30', '20-30'),
        ('30-50', '30-50'), ('50+', '50 and over')]
AGE_PARAMS = {'18-19': ('18', '19'), '20-30': ('20', '30'),
              '30-50': ('30', '50'), '50+': ('50', '200')}
SORTS = [('', 'Site order'), ('viewers', 'Most viewers'), ('followers', 'Most followers'),
         ('newest', 'Newest first')]


def notify(msg, heading='JFN Cams', ms=4500):
    xbmcgui.Dialog().notification(heading, msg, xbmcgui.NOTIFICATION_INFO, ms)


def plugin_url(params):
    return BASE + '?' + urlencode(params)


# ---------------- local stores ----------------

def _load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return default
    return default


def _save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception:
        pass


def load_favs():
    return _load_json(FAV_FILE, [])


def fav_slugs():
    return [f.get('slug') for f in load_favs()]


def load_filters():
    f = _load_json(FILTER_FILE, {})
    return {'region': f.get('region', ''), 'age': f.get('age', ''),
            'tag': f.get('tag', ''), 'new_only': bool(f.get('new_only', False)),
            'sort': f.get('sort', '')}


def save_filters(f):
    _save_json(FILTER_FILE, f)


def filters_active(f):
    return bool(f['region'] or f['age'] or f['tag'] or f['new_only'])


def filters_summary(f):
    bits = []
    for code, label in REGIONS:
        if f['region'] == code and code:
            bits.append(label)
    if f['age']:
        bits.append('Age ' + f['age'])
    if f['tag']:
        bits.append('#' + f['tag'])
    if f['new_only']:
        bits.append('New only')
    for code, label in SORTS:
        if f['sort'] == code and code:
            bits.append(label)
    return ' · '.join(bits) if bits else 'Off'


def apply_filters(query, f):
    q = dict(parse_qsl(query))
    if f['region']:
        q['regions'] = f['region']
    if f['age'] in AGE_PARAMS:
        q['from_age'], q['to_age'] = AGE_PARAMS[f['age']]
    if f['tag']:
        q['hashtags'] = f['tag']
    if f['new_only']:
        q['new_cams'] = 'true'
    return urlencode(q)


def sort_rooms(rooms, f):
    if f['sort'] == 'viewers':
        return sorted(rooms, key=lambda r: r.get('num_users', 0), reverse=True)
    if f['sort'] == 'followers':
        return sorted(rooms, key=lambda r: r.get('num_followers', 0), reverse=True)
    if f['sort'] == 'newest':
        return sorted(rooms, key=lambda r: r.get('start_dt_utc', ''), reverse=True)
    return rooms


def record_history(slug, img):
    hist = _load_json(HIST_FILE, [])
    hist = [h for h in hist if h.get('slug') != slug]
    hist.insert(0, {'slug': slug, 'img': img, 'ts': int(time.time())})
    _save_json(HIST_FILE, hist[:50])


# ---------------- login ----------------

def ensure_login():
    if camsite.has_session_cookie() and camsite.logged_in_live():
        return True
    ok, msg = camsite.do_login(ADDON.getSetting('username').strip(),
                               ADDON.getSetting('password'))
    notify(msg)
    if not ok and 'settings first' in msg:
        ADDON.openSettings()
    return ok


# ---------------- rendering ----------------

def add_room(room, favs):
    slug = room.get('username', '')
    if not slug:
        return
    img = room.get('img', '')
    viewers = room.get('num_users', 0)
    followers = room.get('num_followers', 0)
    subject = (room.get('room_subject') or room.get('subject') or '').strip()
    loc = room.get('location') or room.get('country') or ''
    meta = 'Viewers: %s   Followers: %s' % (viewers, followers)
    if loc:
        meta += '   ' + loc
    plot = (subject + '\n' + meta) if subject else meta
    tags = room.get('tags') or []
    if tags:
        plot += '\n' + ' '.join('#' + t for t in tags[:8])
    status = room.get('current_show', 'public')
    playable = status == 'public'
    li = xbmcgui.ListItem(label=slug)
    li.setArt({'thumb': img, 'icon': img, 'fanart': img})
    li.setInfo('video', {'title': slug, 'plot': plot, 'mediatype': 'video'})
    menu = []
    if room.get('is_following'):
        menu.append(('Unfollow ' + slug, 'RunPlugin(%s)' % plugin_url({'mode': 'unfollow', 'slug': slug})))
    else:
        menu.append(('Follow ' + slug, 'RunPlugin(%s)' % plugin_url({'mode': 'follow', 'slug': slug})))
    if slug in favs:
        menu.append(('Remove from My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_del', 'slug': slug})))
    else:
        menu.append(('Add to My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_add', 'slug': slug, 'img': img})))
    for t in tags[:3]:
        menu.append(('More like this: #%s' % t, 'RunPlugin(%s)' % plugin_url({'mode': 'settag', 'tag': t})))
    li.addContextMenuItems(menu)
    if playable:
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'play', 'slug': slug, 'img': img}), li, False)
    else:
        li.setLabel(slug + '  [' + status + ']')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'offline', 'slug': slug, 'status': status}), li, False)


def filters_row(back_params):
    f = load_filters()
    label = 'Filters: %s  (tap to change)' % filters_summary(f)
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'filters', 'back': urlencode(back_params)}), li, True)


def list_rooms(query, title, filtered=True):
    xbmcplugin.setContent(HANDLE, 'videos')
    f = load_filters()
    if filtered:
        filters_row({'mode': 'list', 'query': query, 'title': title})
        query = apply_filters(query, f)
    try:
        rooms, total = camsite.api_rooms(query)
    except Exception as e:
        notify('Could not load rooms: %s' % e)
        rooms, total = [], 0
    rooms = sort_rooms(rooms, f)
    favs = fav_slugs()
    for room in rooms:
        add_room(room, favs)
    q = dict(parse_qsl(query))
    offset = int(q.get('offset', '0'))
    if rooms and offset + len(rooms) < total:
        q['offset'] = str(offset + int(q.get('limit', str(LIMIT))))
        li = xbmcgui.ListItem(label='Next page >>')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'list', 'query': urlencode(q), 'title': title}), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def root_menu():
    xbmcplugin.setContent(HANDLE, 'files')
    f = load_filters()
    items = [
        ('Featured', {'mode': 'list', 'query': 'limit=%d&offset=0' % LIMIT, 'title': 'Featured'}),
        ('Female', {'mode': 'list', 'query': 'genders=f&limit=%d&offset=0' % LIMIT, 'title': 'Female'}),
        ('Male', {'mode': 'list', 'query': 'genders=m&limit=%d&offset=0' % LIMIT, 'title': 'Male'}),
        ('Couples', {'mode': 'list', 'query': 'genders=c&limit=%d&offset=0' % LIMIT, 'title': 'Couples'}),
        ('Trans', {'mode': 'list', 'query': 'genders=t&limit=%d&offset=0' % LIMIT, 'title': 'Trans'}),
        ('New cams', {'mode': 'list', 'query': 'new_cams=true&limit=%d&offset=0' % LIMIT, 'title': 'New cams'}),
        ('Top cams', {'mode': 'top'}),
        ('Search...', {'mode': 'search'}),
        ('Filters: %s' % filters_summary(f), {'mode': 'filters', 'back': ''}),
    ]
    followed_label = 'Followed cams (online)'
    if camsite.has_session_cookie():
        try:
            _, total = camsite.api_rooms('enable_recommendations=true&follow=true&limit=1&offline=false&offset=0')
            if total:
                followed_label = 'Followed cams (online) - %d on now' % total
        except Exception:
            pass
    items += [
        (followed_label, {'mode': 'followed', 'offline': 'false'}),
        ('Followed cams (offline)', {'mode': 'followed', 'offline': 'true'}),
        ('My Favorites', {'mode': 'favorites'}),
        ('History', {'mode': 'history'}),
        ('Go to room by name...', {'mode': 'goto'}),
    ]
    if camsite.has_session_cookie():
        items.append(('Log out (%s)' % ADDON.getSetting('username'), {'mode': 'logout'}))
    else:
        items.append(('Log in', {'mode': 'login'}))
    for label, params in items:
        li = xbmcgui.ListItem(label=label)
        folder = params.get('mode') in ('list', 'followed', 'favorites', 'history', 'top', 'filters')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, folder)
    xbmcplugin.endOfDirectory(HANDLE)


def filters_menu(back):
    xbmcplugin.setContent(HANDLE, 'files')
    f = load_filters()
    back_params = dict(parse_qsl(back)) if back else {}
    rows = [
        ('Region: %s' % dict(REGIONS).get(f['region'], 'Any region'), 'region'),
        ('Age: %s' % (f['age'] or 'Any age'), 'age'),
        ('Tag: %s' % (('#' + f['tag']) if f['tag'] else 'None'), 'tag'),
        ('New cams only: %s' % ('On' if f['new_only'] else 'Off'), 'new_only'),
        ('Sort: %s' % dict(SORTS).get(f['sort'], 'Site order'), 'sort'),
        ('Clear all filters', 'clear'),
    ]
    for label, dim in rows:
        li = xbmcgui.ListItem(label=label)
        params = {'mode': 'setfilter', 'dim': dim, 'back': back}
        if back_params.get('query'):
            q = dict(parse_qsl(back_params['query']))
            if q.get('genders'):
                params['g'] = q['genders']
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def tags_view(g, page, back):
    xbmcplugin.setContent(HANDLE, 'files')
    try:
        tags, last = camsite.api_tags(g, page)
    except Exception as e:
        notify('Could not load tags: %s' % e)
        tags, last = [], page
    for t in tags:
        name = t.get('hashtag', '')
        if not name:
            continue
        label = name
        cnt = t.get('room_count') or t.get('count') or t.get('num_rooms')
        if cnt:
            label = '%s  (%s)' % (name, cnt)
        li = xbmcgui.ListItem(label=label)
        tops = t.get('top_rooms') or []
        if tops and tops[0].get('img'):
            li.setArt({'thumb': tops[0]['img'], 'icon': tops[0]['img']})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'settag', 'tag': name, 'back': back}), li, False)
    if page < last:
        li = xbmcgui.ListItem(label='Next page >>')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'tags', 'g': g, 'page': str(page + 1), 'back': back}), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def top_view():
    # Measured shape (2026-11-13): {top: [{room_slug, room_user, points,
    # viewers, image_url}], ...} - the hourly contest leaders.
    xbmcplugin.setContent(HANDLE, 'videos')
    entries = []
    try:
        entries = camsite.api_leaderboard().get('top', []) or []
    except Exception as e:
        notify('Top cams unavailable: %s' % e)
    favs = fav_slugs()
    shown = 0
    for ent in entries:
        slug = ent.get('room_slug') or ent.get('room_user')
        if not slug:
            continue
        room = {'username': slug,
                'img': ent.get('image_url', ''),
                'num_users': ent.get('viewers', 0),
                'num_followers': 0,
                'room_subject': 'Top cam - %s contest points' % ent.get('points', ''),
                'current_show': 'public',
                'tags': []}
        add_room(room, favs)
        shown += 1
    if not shown:
        li = xbmcgui.ListItem(label='Top cams unavailable right now')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def search_view():
    kb = xbmcgui.Dialog().input('Search rooms', type=xbmcgui.INPUT_ALPHANUM)
    if not kb:
        return
    term = kb.strip()
    if not term:
        return
    # Measured 2026-11-13: the room-list API IGNORES a keywords parameter (it
    # returns the standard list). Real search here = tag match first, then a
    # client-side scan of the live lists for name/subject/tag matches.
    xbmcplugin.setContent(HANDLE, 'videos')
    rooms = []
    low = term.lower()
    if ' ' not in term:
        try:
            rooms, _ = camsite.api_rooms('hashtags=%s&limit=%d&offset=0' % (quote(low), LIMIT))
        except Exception:
            rooms = []
    if not rooms:
        seen = set()
        try:
            for page in range(5):
                batch, _ = camsite.api_rooms('limit=%d&offset=%d' % (LIMIT, page * LIMIT))
                if not batch:
                    break
                for r in batch:
                    slug = r.get('username', '')
                    hay = (slug + ' ' + (r.get('room_subject') or '') + ' ' +
                           ' '.join(r.get('tags') or [])).lower()
                    if low in hay and slug not in seen:
                        seen.add(slug)
                        rooms.append(r)
        except Exception:
            pass
    favs = fav_slugs()
    for room in rooms[:LIMIT]:
        add_room(room, favs)
    if not rooms:
        li = xbmcgui.ListItem(label='No rooms found for "%s"' % term)
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def followed_view(offline):
    if not ensure_login():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    list_rooms(camsite.followed_query(offline == 'true'), 'Followed', filtered=False)


def _status_items(entries, kind):
    xbmcplugin.setContent(HANDLE, 'videos')
    if not entries:
        label = ('No favorites yet - use the context menu on a room' if kind == 'favorites'
                 else 'No history yet')
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    favs = fav_slugs()
    for ent in entries:
        slug = ent.get('slug', '')
        img = ent.get('img', '')
        if not slug:
            continue
        try:
            _, status = camsite.resolve_stream(slug)
        except Exception:
            status = 'unknown'
        li = xbmcgui.ListItem(label=slug + '  [' + status + ']')
        li.setArt({'thumb': img, 'icon': img, 'fanart': img})
        li.setInfo('video', {'title': slug, 'plot': 'Status: ' + status, 'mediatype': 'video'})
        if kind == 'favorites':
            menu = [('Remove from My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_del', 'slug': slug}))]
        else:
            menu = [('Remove from History', 'RunPlugin(%s)' % plugin_url({'mode': 'hist_del', 'slug': slug}))]
        li.addContextMenuItems(menu)
        if status == 'public':
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'play', 'slug': slug, 'img': img}), li, False)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'offline', 'slug': slug, 'status': status}), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def favorites_view():
    _status_items(load_favs(), 'favorites')


def history_view():
    _status_items(_load_json(HIST_FILE, []), 'history')


def relay_alive():
    try:
        with urlopen('http://127.0.0.1:%d/ping' % relaymod.PORT, timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def play(slug, img=''):
    try:
        url, status = camsite.resolve_stream(slug)
    except Exception as e:
        notify('Could not resolve the stream: %s' % e)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if status != 'public' or not url:
        notify('%s is not in a public show right now (%s)' % (slug, status))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not relay_alive():
        notify('The stream relay is not running - restart Kodi once after installing this update')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    record_history(slug, img)
    li = xbmcgui.ListItem(path=relaymod.play_url(slug))
    li.setInfo('video', {'title': slug})
    li.setMimeType('application/vnd.apple.mpegurl')
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _go_back(back):
    if back:
        xbmc.executebuiltin('Container.Update(%s)' % plugin_url(dict(parse_qsl(back))))
    else:
        xbmc.executebuiltin('Container.Update(%s)' % plugin_url({'mode': 'filters', 'back': back}))


def set_filter(dim, back, g=''):
    f = load_filters()
    dlg = xbmcgui.Dialog()
    if dim == 'region':
        labels = [lbl for _, lbl in REGIONS]
        i = dlg.select('Region', labels)
        if i >= 0:
            f['region'] = REGIONS[i][0]
    elif dim == 'age':
        labels = [lbl for _, lbl in AGES]
        i = dlg.select('Age', labels)
        if i >= 0:
            f['age'] = AGES[i][0]
    elif dim == 'sort':
        labels = [lbl for _, lbl in SORTS]
        i = dlg.select('Sort', labels)
        if i >= 0:
            f['sort'] = SORTS[i][0]
    elif dim == 'new_only':
        f['new_only'] = not f['new_only']
    elif dim == 'clear':
        f = {'region': '', 'age': '', 'tag': '', 'new_only': False, 'sort': ''}
    elif dim == 'tag':
        # bounce to the tag picker for this context's gender
        xbmc.executebuiltin('Container.Update(%s)' % plugin_url({'mode': 'tags', 'g': g, 'page': '1', 'back': back}))
        return
    save_filters(f)
    _go_back(back)


def set_tag(tag, back):
    f = load_filters()
    f['tag'] = tag
    save_filters(f)
    notify('Filter set: #%s' % tag)
    _go_back(back)


# ---------------- routing ----------------

def main():
    mode = PARAMS.get('mode', '')
    if mode == 'list':
        list_rooms(PARAMS.get('query', 'limit=%d&offset=0' % LIMIT), PARAMS.get('title', ''))
    elif mode == 'followed':
        followed_view(PARAMS.get('offline', 'false'))
    elif mode == 'favorites':
        favorites_view()
    elif mode == 'history':
        history_view()
    elif mode == 'top':
        top_view()
    elif mode == 'search':
        search_view()
    elif mode == 'filters':
        filters_menu(PARAMS.get('back', ''))
    elif mode == 'setfilter':
        set_filter(PARAMS.get('dim', ''), PARAMS.get('back', ''), PARAMS.get('g', ''))
    elif mode == 'tags':
        tags_view(PARAMS.get('g', ''), int(PARAMS.get('page', '1')), PARAMS.get('back', ''))
    elif mode == 'settag':
        set_tag(PARAMS.get('tag', ''), PARAMS.get('back', ''))
    elif mode == 'play':
        play(PARAMS.get('slug', ''), PARAMS.get('img', ''))
    elif mode == 'offline':
        notify('%s is %s right now' % (PARAMS.get('slug', ''), PARAMS.get('status', 'offline')))
    elif mode == 'goto':
        kb = xbmcgui.Dialog().input('Room name', type=xbmcgui.INPUT_ALPHANUM)
        if kb:
            xbmc.executebuiltin('PlayMedia(%s)' % plugin_url({'mode': 'play', 'slug': kb.strip().lower()}))
    elif mode == 'login':
        ok, msg = (True, 'Already logged in') if (camsite.has_session_cookie() and camsite.logged_in_live()) else \
            camsite.do_login(ADDON.getSetting('username').strip(), ADDON.getSetting('password'))
        notify(msg)
        if not ok and 'settings first' in msg:
            ADDON.openSettings()
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'logout':
        try:
            camsite.http(camsite.SITE + '/auth/logout/')
        except Exception:
            pass
        camsite.clear_session()
        notify('Logged out')
        xbmc.executebuiltin('Container.Refresh')
    elif mode in ('follow', 'unfollow'):
        if ensure_login():
            ok, msg = camsite.follow_action(PARAMS.get('slug', ''), mode == 'follow')
            notify(msg)
            if ok:
                xbmc.executebuiltin('Container.Refresh')
    elif mode == 'fav_add':
        favs = load_favs()
        slug = PARAMS.get('slug', '')
        if slug and slug not in fav_slugs():
            favs.append({'slug': slug, 'img': PARAMS.get('img', '')})
            _save_json(FAV_FILE, favs)
            notify('Added ' + slug + ' to My Favorites')
    elif mode == 'fav_del':
        slug = PARAMS.get('slug', '')
        _save_json(FAV_FILE, [f for f in load_favs() if f.get('slug') != slug])
        notify('Removed ' + slug + ' from My Favorites')
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'hist_del':
        slug = PARAMS.get('slug', '')
        _save_json(HIST_FILE, [h for h in _load_json(HIST_FILE, []) if h.get('slug') != slug])
        xbmc.executebuiltin('Container.Refresh')
    else:
        root_menu()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        # A directory must never die silently (the 04:07 root failure class):
        # render the error as an item instead of raising.
        try:
            notify('Something failed: %s' % e)
            li = xbmcgui.ListItem(label='Error: %s' % e)
            xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass
