# JFN Cams service: runs the local stream relay and the online alerts.
import os, sys, json, time

import xbmc, xbmcaddon, xbmcgui, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_DIR, 'resources', 'lib'))

import camsite
import relay
import chatclient
import chatoverlay

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
camsite.init(PROFILE)

STATE_FILE = os.path.join(PROFILE, 'alerts_state.json')


def _setting(key):
    try:
        return ADDON.getSetting(key)
    except Exception:
        return ''


def _load_state():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_state(state):
    try:
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f)
    except Exception:
        pass


def _fav_slugs():
    try:
        with open(os.path.join(PROFILE, 'favorites.json'), encoding='utf-8') as f:
            return [x.get('slug') for x in json.load(f) if x.get('slug')]
    except Exception:
        return []


def check_alerts(state):
    """One poll cycle. Returns the updated baseline set of online slugs."""
    online = set()
    if not camsite.has_session_cookie():
        return state.get('online', [])
    try:
        rooms, _ = camsite.api_rooms(camsite.followed_query(False))
        online |= {r.get('username') for r in rooms if r.get('username')}
    except Exception:
        return state.get('online', [])
    favs = _fav_slugs()
    if favs and len(favs) <= 20:
        for slug in favs:
            if slug in online:
                continue
            try:
                _, status = camsite.resolve_stream(slug)
                if status == 'public':
                    online.add(slug)
            except Exception:
                pass
    prev = set(state.get('online', []))
    if state.get('primed'):
        for slug in sorted(online - prev):
            xbmcgui.Dialog().notification('JFN Cams', '%s is online now' % slug,
                                          xbmcgui.NOTIFICATION_INFO, 6000)
    state['online'] = sorted(online)
    state['primed'] = True
    _save_state(state)
    return state['online']


def main():
    server = relay.make_server()
    import threading
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    relay.TRACE = lambda m: xbmc.log('JFNRELAY ' + m, xbmc.LOGINFO)
    chatclient.TRACE = lambda m: xbmc.log('JFNCHAT ' + m, xbmc.LOGINFO)
    xbmc.log('JFN Cams relay listening on 127.0.0.1:%d' % relay.PORT, xbmc.LOGINFO)

    monitor = xbmc.Monitor()
    state = _load_state()
    last_check = 0.0
    chat_slug = None
    overlay = {'dlg': None, 'slug': None, 'suppressed': None}
    player = xbmc.Player()
    while not monitor.abortRequested():
        # Chat session follows playback of our own streams (stage 2).
        try:
            slug = None
            if player.isPlayingVideo():
                slug = chatclient.slug_from_playing_file(player.getPlayingFile() or '')
            if slug != chat_slug:
                if chatclient.ACTIVE_SESSION is not None:
                    chatclient.ACTIVE_SESSION.stop()
                    chatclient.ACTIVE_SESSION = None
                if overlay['dlg'] is not None:
                    overlay['dlg'].close()
                    overlay['dlg'] = None
                chat_slug = slug
                if slug and _setting('chat_enable') != 'false':
                    sess = chatclient.ChatSession(slug)
                    if sess.start():
                        chatclient.ACTIVE_SESSION = sess
            # Overlay follows the live chat session; a manual close
            # suppresses it for the rest of that room.
            chatclient.SEND_ENABLED = _setting('chat_send_enable') == 'true'
            sess = chatclient.ACTIVE_SESSION
            if (sess is not None and overlay['dlg'] is None
                    and overlay['suppressed'] != sess.slug):
                import threading

                overlay['dlg'] = 'opening'  # claim the slot before the thread runs

                def _show(sess=sess):
                    dlg = None
                    try:
                        dlg = chatoverlay.ChatOverlay(sess)
                        overlay['dlg'] = dlg
                        overlay['slug'] = sess.slug
                        dlg.doModal()
                    except Exception:
                        overlay['suppressed'] = sess.slug
                    if dlg is not None and dlg.closed_by_user:
                        overlay['suppressed'] = sess.slug
                    overlay['dlg'] = None

                threading.Thread(target=_show, daemon=True).start()
            if sess is None:
                overlay['suppressed'] = None
        except Exception:
            pass
        if _setting('alerts_enable') == 'true':
            try:
                minutes = int(_setting('alerts_minutes') or '10')
            except Exception:
                minutes = 10
            if time.time() - last_check >= max(2, minutes) * 60:
                last_check = time.time()
                try:
                    check_alerts(state)
                except Exception:
                    pass
        if monitor.waitForAbort(5):
            break
    try:
        server.shutdown()
    except Exception:
        pass


if __name__ == '__main__':
    main()
