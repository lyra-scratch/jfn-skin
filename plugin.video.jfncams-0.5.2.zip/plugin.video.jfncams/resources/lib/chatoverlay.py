# Chat overlay window (stage 2) — runs in the service process.
#
# A right-side panel over the playing video: recent chat lines, a Type
# button (the phone remote's keyboard feeds Kodi's input dialog), and
# player keys forwarded so watching still works while it is open. Back
# closes it; the service keeps it closed for that room afterwards.
import re
import threading
import time

import xbmc
import xbmcgui

import chatclient

# 1280x720 design space
PANEL_X, PANEL_Y, PANEL_W, PANEL_H = 830, 60, 420, 560
LINE_COUNT = 16

ACTION_NAV_BACK = 92
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_PAUSE = 12
ACTION_STOP = 13
ACTION_PLAY = 68
ACTION_STEP_FORWARD = 21
ACTION_STEP_BACK = 22
ACTION_BIG_STEP_FORWARD = 23
ACTION_BIG_STEP_BACK = 24


_HEX = re.compile(r'^#[0-9a-fA-F]{6}$')


def format_lines(messages, width_user=14):
    """Buffer messages -> display lines, newest last. Pure; unit-tested.
    A sender colour from the site (plain #RRGGBB only) colours the name."""
    out = []
    for m in messages[-LINE_COUNT:]:
        user = (m.get('user') or '').strip()
        text = (m.get('text') or '').replace('\n', ' ').strip()
        if not text:
            continue
        if user:
            color = m.get('color') or ''
            if _HEX.match(color):
                out.append('[B][COLOR %s]%s[/COLOR]:[/B] %s' % (color, user[:width_user], text))
            else:
                out.append('[B]%s:[/B] %s' % (user[:width_user], text))
        else:
            out.append(text)
    return out


class ChatOverlay(xbmcgui.WindowDialog):
    def __init__(self, session, img='', info_lines=None):
        super().__init__()
        self.session = session
        self._img = img
        self._info = [l for l in (info_lines or []) if l][:2]
        self.closed_by_user = False
        self._last_seq = 0
        self._stop = threading.Event()
        self._bg = xbmcgui.ControlImage(PANEL_X, PANEL_Y, PANEL_W, PANEL_H,
                                        '', colorDiffuse='CC0B0E1A')
        title_x = PANEL_X + 14
        self._thumb = None
        if self._img:
            self._thumb = xbmcgui.ControlImage(PANEL_X + 14, PANEL_Y + 10, 56, 32, self._img)
            title_x = PANEL_X + 80
        self._title = xbmcgui.ControlLabel(title_x, PANEL_Y + 8, PANEL_W - (title_x - PANEL_X) - 14, 30,
                                           '', textColor='FF4CD7E6')
        body_y = PANEL_Y + 44
        info_ctls = []
        for line in self._info:
            info_ctls.append(xbmcgui.ControlLabel(
                PANEL_X + 14, body_y - 4, PANEL_W - 28, 22, line,
                textColor='FFB9C4CC', font='font10'))
            body_y += 24
        self._body = xbmcgui.ControlTextBox(PANEL_X + 14, body_y,
                                            PANEL_W - 28,
                                            PANEL_H - (body_y - PANEL_Y) - 56)
        self._type_btn = xbmcgui.ControlButton(PANEL_X + 14, PANEL_Y + PANEL_H - 48,
                                               PANEL_W - 28, 36, 'Type a message')
        controls = [self._bg, self._title] + info_ctls + [self._body, self._type_btn]
        if self._thumb is not None:
            controls.insert(1, self._thumb)
        self.addControls(controls)
        self.setFocus(self._type_btn)

    def onInit(self):
        self._title.setLabel('Chat — %s' % self.session.slug)
        t = threading.Thread(target=self._refresh_loop, daemon=True)
        t.start()

    def _refresh_loop(self):
        while not self._stop.is_set():
            try:
                msgs = self.session.buffer.since(0)
                lines = format_lines(msgs)
                self._body.setText('\n'.join(lines))
            except Exception:
                pass
            self._stop.wait(1.0)

    def onClick(self, controlId):
        if controlId == self._type_btn.getId():
            text = xbmcgui.Dialog().input('Message to %s' % self.session.slug,
                                          type=xbmcgui.INPUT_ALPHANUM)
            if text:
                chatclient.send_message(self.session, text)

    def onAction(self, action):
        aid = action.getId()
        if aid in (ACTION_NAV_BACK, ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU):
            self.closed_by_user = True
            self.close()
            return
        player = xbmc.Player()
        if aid == ACTION_PAUSE:
            player.pause()
        elif aid == ACTION_PLAY:
            player.play()
        elif aid == ACTION_STOP:
            player.stop()
            self.close()
        elif aid in (ACTION_STEP_FORWARD, ACTION_BIG_STEP_FORWARD):
            player.seekTime(min(player.getTime() + 10, 10 ** 9))
        elif aid in (ACTION_STEP_BACK, ACTION_BIG_STEP_BACK):
            player.seekTime(max(player.getTime() - 10, 0))
        else:
            super().onAction(action)

    def close(self):
        self._stop.set()
        try:
            super().close()
        except Exception:
            pass
