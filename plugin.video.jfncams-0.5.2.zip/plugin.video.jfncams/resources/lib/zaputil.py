# Zapping support (build B): launch-context store + pure pickers.
# The live zap action lives in default.py; everything here is testable
# without Kodi.
import json
import random


def save_context(path, back, slug):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'back': back, 'slug': slug}, f)
    except Exception:
        pass


def load_context(path):
    try:
        with open(path, encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def public_slugs(rooms):
    out = []
    for r in rooms or []:
        slug = r.get('username')
        if slug and r.get('current_show', 'public') == 'public':
            out.append(slug)
    return out


def step(slugs, current, direction):
    """Next/previous slug with wraparound. If the current room is not in
    the list, enter the list at the edge the direction points from."""
    if not slugs:
        return None
    if current in slugs:
        i = slugs.index(current)
        return slugs[(i + (1 if direction >= 0 else -1)) % len(slugs)]
    return slugs[0] if direction >= 0 else slugs[-1]


def random_pick(slugs, current, rng=None):
    pool = [s for s in slugs if s != current]
    if not pool:
        return current if slugs else None
    return (rng or random).choice(pool)
