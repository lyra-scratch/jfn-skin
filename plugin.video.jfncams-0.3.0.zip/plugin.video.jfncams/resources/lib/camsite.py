# Shared site/session layer for JFN Cams (plugin + service both import this).
# Stdlib only. The profile dir holds cookies.txt (session), shared by both
# processes through the file: every request reloads/saves it, so a login done
# in the plugin is visible to the service without a restart.
import os, re, json
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPCookieProcessor
from http.cookiejar import MozillaCookieJar

SITE = 'https://chaturbate.com'
API = SITE + '/api/ts/roomlist/room-list/'
TAGAPI = SITE + '/api/ts/hashtags/tag-table-data/'
LEADERBOARD = SITE + '/api/ts/contest/leaderboard/'
UA_BROWSER = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'
UA_IPAD = 'Mozilla/5.0 (iPad; CPU OS 8_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B410 Safari/600.1.4'

_profile = None
_cookie_file = None


def init(profile_dir):
    global _profile, _cookie_file
    _profile = profile_dir
    if not os.path.isdir(_profile):
        os.makedirs(_profile)
    _cookie_file = os.path.join(_profile, 'cookies.txt')


def _jar():
    cj = MozillaCookieJar(_cookie_file)
    if _cookie_file and os.path.exists(_cookie_file):
        try:
            cj.load(ignore_discard=True, ignore_expires=True)
        except Exception:
            pass
    return cj


def _save(cj):
    try:
        cj.save(ignore_discard=True, ignore_expires=True)
    except Exception:
        pass


def _transient(e):
    import http.client, urllib.error
    return isinstance(e, (http.client.RemoteDisconnected, http.client.IncompleteRead,
                          ConnectionError, TimeoutError, urllib.error.URLError))


def _get_bytes(opener, req, timeout, attempts=3):
    """GET-style fetch: open AND read, retrying the whole request on the
    edge's intermittent mid-stream drops (observed repeatedly 2026-11-13:
    connections open, then the body is cut partway)."""
    import time as _time, urllib.error
    last = None
    for i in range(attempts):
        try:
            with opener.open(req, timeout=timeout) as resp:
                return resp.status if hasattr(resp, 'status') else 200, resp.read()
        except urllib.error.HTTPError as e:
            try:
                return e.code, e.read()
            except Exception:
                return e.code, b''
        except Exception as e:
            if not _transient(e):
                raise
            last = e
            _time.sleep(1.0 + i)
    raise last


def http(url, data=None, headers=None, ua=UA_BROWSER, timeout=30, raw=False):
    cj = _jar()
    opener = build_opener(HTTPCookieProcessor(cj))
    hdrs = {'User-Agent': ua, 'Accept-Language': 'en-US,en;q=0.9'}
    if headers:
        hdrs.update(headers)
    body = urlencode(data).encode('utf-8') if data is not None else None
    req = Request(url, data=body, headers=hdrs)
    if data is None:
        _, data_raw = _get_bytes(opener, req, timeout)
    else:
        # POSTs are not blindly retried (login/follow are state-changing);
        # one retry on a connection that died before any response.
        import time as _time, urllib.error
        try:
            with opener.open(req, timeout=timeout) as resp:
                data_raw = resp.read()
        except Exception as e:
            if not _transient(e) or isinstance(e, urllib.error.HTTPError):
                raise
            _time.sleep(1.0)
            with opener.open(req, timeout=timeout) as resp:
                data_raw = resp.read()
    _save(cj)
    return data_raw if raw else data_raw.decode('utf-8', 'replace')


def http_status(url, ua=UA_IPAD, timeout=30):
    """Fetch bytes for a CDN object (playlist/segment). Returns (status, bytes)."""
    cj = _jar()
    opener = build_opener(HTTPCookieProcessor(cj))
    req = Request(url, headers={'User-Agent': ua, 'Accept-Language': 'en-US,en;q=0.9'})
    return _get_bytes(opener, req, timeout)


def has_session_cookie():
    for c in _jar():
        if c.name == 'sessionid' and 'chaturbate.com' in c.domain and c.value:
            return True
    return False


def clear_session():
    cj = _jar()
    cj.clear()
    _save(cj)


def api_rooms(query):
    data = json.loads(http(API + '?' + query))
    return data.get('rooms', []), data.get('total_count', 0)


def api_tags(gender='', page=1, limit=100):
    """Tag index from the site's hashtag table. Returns (tags, last_page).
    Measured shape (2026-11-13): {hashtags: [{hashtag, room_count,
    viewer_count, top_rooms}], total: N} - no page fields, so the last page
    is computed from total."""
    q = 'sort=ht&page=%d&limit=%d' % (page, limit)
    if gender:
        q += '&g=' + gender
    data = json.loads(http(TAGAPI + '?' + q))
    tags = data.get('hashtags', []) or []
    total = data.get('total') or 0
    if total:
        last = max(page, -(-int(total) // limit))
    else:
        last = page + 1 if len(tags) >= limit else page
    return tags, int(last)


def api_leaderboard():
    return json.loads(http(LEADERBOARD))


def resolve_stream(slug):
    """Return (m3u8_url, room_status)."""
    hdrs = {'X-Requested-With': 'XMLHttpRequest',
            'Referer': SITE + '/' + slug + '/',
            'Content-Type': 'application/x-www-form-urlencoded'}
    raw = http(SITE + '/get_edge_hls_url_ajax/',
               data={'room_slug': slug, 'bandwidth': 'high'}, headers=hdrs, ua=UA_IPAD)
    data = json.loads(raw)
    return data.get('url'), data.get('room_status', 'unknown')


def followed_query(offline):
    return ('enable_recommendations=true&follow=true&limit=100&offline=%s&offset=0'
            % ('true' if offline else 'false'))


def logged_in_live():
    try:
        html = http(SITE + '/followed-cams/')
    except Exception:
        return False
    return '>Chaturbate Login</h1>' not in html


def do_login(username, password):
    """Returns (ok, message)."""
    if not username or not password:
        return False, 'Set your username and password in the add-on settings first'
    login_url = SITE + '/auth/login/?next=/followed-cams/'
    try:
        html = http(login_url)
    except Exception as e:
        return False, 'Could not reach the login page: %s' % e
    m = re.search(r'"csrfmiddlewaretoken"\s+value="([^"]+)"', html)
    if not m:
        return False, 'Login form changed on the site - token not found'
    post = {'next': '/followed-cams/', 'csrfmiddlewaretoken': m.group(1),
            'username': username, 'password': password, 'rememberme': 'on'}
    try:
        resp = http(login_url, data=post, headers={'Referer': login_url})
    except Exception as e:
        return False, 'Login request failed: %s' % e
    if '>Chaturbate Login</h1>' in resp:
        if 'captcha' in resp.lower() or 'recaptcha' in resp.lower():
            return False, 'The site demanded a captcha. Log in once on the site, then try again'
        return False, 'Login failed - check your username and password'
    if has_session_cookie():
        return True, 'Logged in as %s' % username
    return False, 'Login did not stick - no session was set'


def follow_action(slug, follow=True):
    """Returns (ok, message). Caller guarantees a live session."""
    path = '/follow/follow/' if follow else '/follow/unfollow/'
    url = SITE + path + slug + '/'
    try:
        html = http(url)
        m = re.search(r'"csrfmiddlewaretoken"\s+value="([^"]+)"', html)
        if not m:
            return False, 'Follow failed - token not found'
        resp = http(url, data={'csrfmiddlewaretoken': m.group(1)},
                    headers={'Referer': SITE + '/'})
        want = '"following": true' if follow else '"following": false'
        if want in resp:
            return True, ('Now following ' if follow else 'Unfollowed ') + slug
        return False, 'The site did not confirm the change'
    except Exception as e:
        return False, 'Follow failed: %s' % e
