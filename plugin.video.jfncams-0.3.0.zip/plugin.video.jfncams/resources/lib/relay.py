# Local relay for JFN Cams.
#
# Why this exists (measured 2026-11-13): the site's stream URLs carry a
# single-use token. The FIRST fetch of a playlist URL returns 200; every later
# fetch of the same URL returns 403, no matter the cookies or user agent.
# Kodi's player touches a stream URL several times (stat, open, playlist
# reloads), so direct playback can never work. The relay is the only client
# that talks to the CDN: it resolves a FRESH stream URL for every playlist
# load, fetches each playlist/segment/part exactly once, caches segment bytes,
# and serves Kodi a plain local HLS feed on 127.0.0.1.
import re, threading
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, quote, urljoin

import camsite

PORT = 57711
BASE_PREFIX = 'http://127.0.0.1:%d' % PORT
CACHE_MAX_ITEMS = 80
CACHE_MAX_BYTES = 64 * 1024 * 1024

_stats = {'resolves': 0, 'playlist_fetches': 0, 'seg_fetches': 0, 'cache_hits': 0}
_stats_lock = threading.Lock()


def _bump(key):
    with _stats_lock:
        _stats[key] += 1


TRACE = None


def _trace(msg):
    cb = TRACE
    if cb is not None:
        try:
            cb(msg)
        except Exception:
            pass


def _base(url):
    try:
        return urlparse(url).path.rsplit('/', 1)[-1] or '?'
    except Exception:
        return '?'


def _host(url):
    try:
        return urlparse(url).netloc or '?'
    except Exception:
        return '?'


def stats():
    with _stats_lock:
        return dict(_stats)


class SegCache:
    def __init__(self):
        self._d = OrderedDict()
        self._bytes = 0
        self._lock = threading.Lock()

    def get(self, url):
        with self._lock:
            if url in self._d:
                self._d.move_to_end(url)
                _bump('cache_hits')
                return self._d[url]
        return None

    def put(self, url, body):
        with self._lock:
            if url in self._d:
                self._bytes -= len(self._d[url])
            self._d[url] = body
            self._bytes += len(body)
            while len(self._d) > CACHE_MAX_ITEMS or self._bytes > CACHE_MAX_BYTES:
                _, old = self._d.popitem(last=False)
                self._bytes -= len(old)


CACHE = SegCache()

# Never-fail state (the working add-ons' handler semantics): the player must
# never see a failed playlist reload or a failed segment. A dead session is
# refreshed by re-resolving; failing that, the last-good playlist is served
# again; a failed segment fetch is answered with the lane's latest segment.
_state_lock = threading.Lock()
_pl_cache = {}     # chunklist url -> last-good raw playlist text
_pl_slug = {}      # chunklist url -> slug (session refresh source)
_latest_seg = {}   # lane key -> most recent full-segment bytes
_LANE = re.compile(r'seg_(\d+)_\d+_(video|audio)')


def _lane(url):
    m = _LANE.search(_base(url))
    return '%s_%s' % (m.group(1), m.group(2)) if m else None

_URI_ATTR = re.compile(r'URI="([^"]+)"')
_BARE_URI = re.compile(r'^(?!#)(\S+)$')
_SAFE_BASE = re.compile(r'[^A-Za-z0-9._-]')


def _basename(url, fallback):
    """The real file name of a CDN object, sanitised for a URL path.
    Relay URLs MUST carry the true extension in their path: ffmpeg's HLS
    demuxer rejects any segment whose URL path does not end in an allowed
    extension (.m4s/.ts/.mp4/...), no matter what the query string holds.
    (Proven 2026-11-13: '/seg?u=...m4s' -> 'not in allowed_segment_extensions'
    -> empty segments -> instant EOF.)"""
    name = _SAFE_BASE.sub('_', urlparse(url).path.rsplit('/', 1)[-1])
    return name if '.' in name else fallback


def _local(kind, u, prefix):
    fb = 'pl.m3u8' if kind == 'pl' else 'seg.m4s'
    return '%s/%s/%s?u=%s' % (prefix, kind, _basename(u, fb), quote(u, safe=''))


def rewrite_playlist(text, base_url, prefix):
    """Point every object in an HLS playlist back at this relay.
    prefix is '' when the handler serves at root."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append(line)
            continue
        if s.startswith('#'):
            def sub(m):
                u = urljoin(base_url, m.group(1))
                if u.split('?')[0].endswith('.m3u8'):
                    return 'URI="%s"' % _local('pl', u, prefix)
                return 'URI="%s"' % _local('seg', u, prefix)
            out.append(_URI_ATTR.sub(sub, line))
        else:
            u = urljoin(base_url, s)
            if u.split('?')[0].endswith('.m3u8'):
                out.append(_local('pl', u, prefix))
            else:
                out.append(_local('seg', u, prefix))
    return '\n'.join(out) + '\n'


def _fetch_text(url):
    """One upstream playlist fetch. Returns (status, text-or-None); never raises."""
    import time
    t0 = time.time()
    try:
        status, body = camsite.http_status(url)
    except Exception as exc:
        _trace('pl fetch EXC host=%s base=%s %s ms=%d' % (
            _host(url), _base(url), type(exc).__name__, (time.time() - t0) * 1000))
        return 0, None
    _bump('playlist_fetches')
    _trace('pl fetch host=%s base=%s status=%s bytes=%s ms=%d' % (
        _host(url), _base(url), status,
        len(body) if body else 0, (time.time() - t0) * 1000))
    if status != 200 or body is None:
        return status, None
    text = body.decode('utf-8', 'replace')
    _lines = [ln.strip() for ln in text.splitlines()
              if ln.strip() and not ln.startswith('#')]
    _trace('pl serve base=%s endlist=%s items=%d first=%s last=%s' % (
        _base(url), 'EXT-X-ENDLIST' in text, len(_lines),
        _base(_lines[0]) if _lines else '-',
        _base(_lines[-1]) if _lines else '-'))
    return 200, text


def _refresh_chunklist(url):
    """The session behind a chunklist URL died: re-resolve the room, find the
    same lane's chunklist in the fresh master, fetch and serve that."""
    with _state_lock:
        slug = _pl_slug.get(url)
    if not slug:
        return None
    try:
        murl, rst = camsite.resolve_stream(slug)
        if not murl or rst != 'public':
            return None
        _st, mtext = _fetch_text(murl)
        if mtext is None:
            return None
        want = _base(url)
        for ln in mtext.splitlines():
            one = ln.strip()
            if one and not one.startswith('#'):
                cand = urljoin(murl, one)
                if _base(cand) == want:
                    _st2, text2 = _fetch_text(cand)
                    if text2 is None:
                        return None
                    with _state_lock:
                        _pl_cache[url] = text2
                        _pl_slug[cand] = slug
                    _trace('pl refreshed base=%s' % want)
                    return rewrite_playlist(text2, cand, BASE_PREFIX)
    except Exception as exc:
        _trace('pl refresh EXC base=%s %s' % (_base(url), type(exc).__name__))
    return None


def fetch_playlist_by_url(url):
    """Fetch one chunklist URL and return it rewritten. On any upstream
    failure: refresh the session, else serve the last-good copy. The player
    never sees a failed reload."""
    status, text = _fetch_text(url)
    if text is not None:
        with _state_lock:
            _pl_cache[url] = text
        return 200, rewrite_playlist(text, url, BASE_PREFIX)
    refreshed = _refresh_chunklist(url)
    if refreshed is not None:
        return 200, refreshed
    with _state_lock:
        cached = _pl_cache.get(url)
    if cached is not None:
        _trace('pl serve CACHED base=%s (upstream status=%s)' % (_base(url), status))
        return 200, rewrite_playlist(cached, url, BASE_PREFIX)
    return (status if status else 502), None


def fetch_playlist_by_slug(slug):
    """Resolve a FRESH stream URL (single-use token) and fetch its master
    playlist, recording which room each variant lane belongs to so a dead
    session can be refreshed lane-by-lane later."""
    try:
        url, room_status = camsite.resolve_stream(slug)
    except Exception as exc:
        _trace('resolve EXC slug=%s %s' % (slug, type(exc).__name__))
        raise
    _bump('resolves')
    _trace('resolve slug=%s room_status=%s ok=%s' % (slug, room_status, bool(url)))
    if not url or room_status != 'public':
        return 404, None
    status, text = _fetch_text(url)
    if text is None:
        return (status if status else 502), None
    with _state_lock:
        for ln in text.splitlines():
            one = ln.strip()
            if one and not one.startswith('#'):
                _pl_slug[urljoin(url, one)] = slug
    return 200, rewrite_playlist(text, url, BASE_PREFIX)


def fetch_segment(url):
    body = CACHE.get(url)
    if body is not None:
        _trace('seg cache-hit base=%s bytes=%d' % (_base(url), len(body)))
        return 200, body
    import time
    t0 = time.time()
    exc_name = None
    try:
        status, body = camsite.http_status(url)
    except Exception as exc:
        exc_name = type(exc).__name__
        status, body = 0, None
        _trace('seg fetch EXC base=%s %s ms=%d' % (
            _base(url), exc_name, (time.time() - t0) * 1000))
    _bump('seg_fetches')
    if exc_name is None:
        _trace('seg fetch base=%s status=%s bytes=%s ms=%d' % (
            _base(url), status, len(body) if body else 0, (time.time() - t0) * 1000))
    if status == 200 and body:
        CACHE.put(url, body)
        lane = _lane(url)
        if lane:
            with _state_lock:
                _latest_seg[lane] = body
        return 200, body
    lane = _lane(url)
    if lane:
        with _state_lock:
            latest = _latest_seg.get(lane)
        if latest:
            _trace('seg LATEST fallback lane=%s for base=%s (status=%s)' % (
                lane, _base(url), status))
            return 200, latest
    if exc_name is not None:
        raise IOError('segment fetch failed: %s' % exc_name)
    return status, body


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        pass

    def _send(self, status, body, ctype='application/octet-stream'):
        if body is None:
            body = b''
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(body)

    def do_HEAD(self):
        self._route()

    def do_GET(self):
        self._route()

    def _route(self):
        try:
            p = urlparse(self.path)
            q = parse_qs(p.query)
            _trace('req %s %s' % (self.command, p.path))
            if p.path.startswith('/play/') and p.path.endswith('.m3u8'):
                slug = p.path[len('/play/'):-len('.m3u8')]
                status, text = fetch_playlist_by_slug(slug)
                self._send(status, text.encode('utf-8') if text else None,
                           'application/vnd.apple.mpegurl')
            elif p.path.startswith('/pl/'):
                target = q.get('u', [''])[0]
                _extra = []
                for _k in ('_HLS_msn', '_HLS_part', '_HLS_skip'):
                    if _k in q:
                        _extra.append('%s=%s' % (_k, q[_k][0]))
                if _extra:
                    _trace('pl blocking-reload forward: %s' % ' '.join(_extra))
                    target += ('&' if '?' in target else '?') + '&'.join(_extra)
                status, text = fetch_playlist_by_url(target)
                self._send(status, text.encode('utf-8') if text else None,
                           'application/vnd.apple.mpegurl')
            elif p.path.startswith('/seg/'):
                status, body = fetch_segment(q.get('u', [''])[0])
                if p.path.endswith(('.m4s', '.mp4', '.m4a')):
                    ctype = 'video/mp4'
                elif p.path.endswith('.ts'):
                    ctype = 'video/mp2t'
                else:
                    ctype = 'application/octet-stream'
                self._send(status, body, ctype)
            elif p.path == '/ping':
                self._send(200, b'ok', 'text/plain')
            elif p.path == '/stats':
                import json
                self._send(200, json.dumps(stats()).encode('utf-8'), 'application/json')
            else:
                self._send(404, b'not found', 'text/plain')
        except Exception as exc:
            _trace('route EXC %s' % type(exc).__name__)
            try:
                self._send(500, b'error', 'text/plain')
            except Exception:
                pass


def make_server(port=PORT):
    global BASE_PREFIX
    BASE_PREFIX = 'http://127.0.0.1:%d' % port
    return ThreadingHTTPServer(('127.0.0.1', port), Handler)


def play_url(slug, port=PORT):
    return 'http://127.0.0.1:%d/play/%s.m3u8' % (port, slug)
