# JFN Cams service: runs the local stream relay and the online alerts.
import os, sys, json, time

import xbmc, xbmcaddon, xbmcgui, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_DIR, 'resources', 'lib'))

import camsite
import relay
import chatclient
import chatoverlay
import hud

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
camsite.init(PROFILE)

STATE_FILE = os.path.join(PROFILE, 'alerts_state.json')
CHAT_STATE_FILE = os.path.join(PROFILE, 'chat_state.json')
INFO_STATE_FILE = os.path.join(PROFILE, 'info_state.json')
HISTORY_FILE = os.path.join(PROFILE, 'history.json')
PENDING_TOASTS = []


def _flag(path):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f).get('enabled') is True
    except Exception:
        return False


def _history_img(slug):
    try:
        with open(HISTORY_FILE, encoding='utf-8') as f:
            for ent in json.load(f):
                if ent.get('slug') == slug and ent.get('img'):
                    return ent['img']
    except Exception:
        pass
    return ''


def _chat_wanted():
    try:
        with open(CHAT_STATE_FILE, encoding='utf-8') as f:
            return json.load(f).get('enabled') is True
    except Exception:
        return False


def _chat_set_wanted(v):
    try:
        with open(CHAT_STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump({'enabled': bool(v)}, f)
    except Exception:
        pass


def _setting(key):
    try:
        return ADDON.getSetting(key)
    except Exception:
        return ''


def _load_state():
    try:
        with open(STATE_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _save_state(state):
    try:
        with open(STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(state, f)
    except Exception:
        pass


def _fav_slugs():
    try:
        with open(os.path.join(PROFILE, 'favorites.json'), encoding='utf-8') as f:
            return [x.get('slug') for x in json.load(f) if x.get('slug')]
    except Exception:
        return []


ZAP_KEYMAP = '''<keymap>
  <fullscreenvideo>
    <keyboard>
      <fastforward>RunPlugin(plugin://plugin.video.jfncams/?mode=zap&amp;dir=next)</fastforward>
      <rewind>RunPlugin(plugin://plugin.video.jfncams/?mode=zap&amp;dir=prev)</rewind>
      <menu>RunPlugin(plugin://plugin.video.jfncams/?mode=inroom)</menu>
      <pagedown>RunPlugin(plugin://plugin.video.jfncams/?mode=zap&amp;dir=next)</pagedown>
      <pageup>RunPlugin(plugin://plugin.video.jfncams/?mode=zap&amp;dir=prev)</pageup>
    </keyboard>
  </fullscreenvideo>
</keymap>
'''


def _write_keymap():
    """Remote keys for surfing + the in-room chat toggle. Keymaps load at
    Kodi start, so this takes effect from the next start after install."""
    try:
        d = xbmcvfs.translatePath('special://profile/keymaps')
        if not xbmcvfs.exists(d):
            xbmcvfs.mkdirs(d)
        path = os.path.join(d, 'jfncams_zap.xml')
        old = ''
        if xbmcvfs.exists(path):
            f = xbmcvfs.File(path)
            old = f.read()
            f.close()
        if old != ZAP_KEYMAP:
            f = xbmcvfs.File(path, 'w')
            f.write(ZAP_KEYMAP)
            f.close()
            xbmc.log('JFN Cams: zap/chat keymap written', xbmc.LOGINFO)
    except Exception:
        pass


def check_alerts(state):
    """One poll cycle. Returns the updated baseline set of online slugs."""
    online = set()
    if not camsite.has_session_cookie():
        return state.get('online', [])
    try:
        rooms, _ = camsite.api_rooms(camsite.followed_query(False))
        online |= {r.get('username') for r in rooms if r.get('username')}
    except Exception:
        return state.get('online', [])
    favs = _fav_slugs()
    if favs and len(favs) <= 20:
        for slug in favs:
            if slug in online:
                continue
            try:
                _, status = camsite.resolve_stream(slug)
                if status == 'public':
                    online.add(slug)
            except Exception:
                pass
    prev = set(state.get('online', []))
    if state.get('primed'):
        for slug in sorted(online - prev):
            PENDING_TOASTS.append('%s is online now' % slug)
    state['online'] = sorted(online)
    state['primed'] = True
    _save_state(state)
    return state['online']


def main():
    _write_keymap()
    server = relay.make_server()
    import threading
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    relay.TRACE = lambda m: xbmc.log('JFNRELAY ' + m, xbmc.LOGINFO)
    chatclient.TRACE = lambda m: xbmc.log('JFNCHAT ' + m, xbmc.LOGINFO)
    xbmc.log('JFN Cams relay listening on 127.0.0.1:%d' % relay.PORT, xbmc.LOGINFO)

    monitor = xbmc.Monitor()
    state = _load_state()
    last_check = 0.0
    chat_slug = None
    overlay = {'dlg': None, 'slug': None, 'suppressed': None}
    hud_state = {'strip': None, 'strip_slug': None, 'strip_text': '',
                 'toast': None, 'toast_until': 0.0}
    player = xbmc.Player()
    while not monitor.abortRequested():
        # Chat is IN-ROOM only (Chad's ruling): off unless he summons it
        # while watching. The state file is written by the in-room toggle
        # and by Back-ing out of the panel. Nothing here reads Settings.
        try:
            slug = None
            if player.isPlayingVideo():
                slug = chatclient.slug_from_playing_file(player.getPlayingFile() or '')
            want = _chat_wanted()
            sess = chatclient.ACTIVE_SESSION
            if slug != chat_slug:
                chat_slug = slug
                if sess is not None:
                    sess.stop()
                    chatclient.ACTIVE_SESSION = sess = None
                if overlay['dlg'] is not None and overlay['dlg'] != 'opening':
                    overlay['dlg'].close()
                    overlay['dlg'] = None
            if slug and want and sess is None:
                s2 = chatclient.ChatSession(slug)
                if s2.start():
                    chatclient.ACTIVE_SESSION = sess = s2
            if (not want or not slug) and sess is not None:
                sess.stop()
                chatclient.ACTIVE_SESSION = sess = None
            if (not want or not slug) and overlay['dlg'] is not None and overlay['dlg'] != 'opening':
                overlay['dlg'].close()
                overlay['dlg'] = None
            chatclient.SEND_ENABLED = False
            if sess is not None and overlay['dlg'] is None:
                import threading
                overlay['dlg'] = 'opening'

                def _show(sess=sess):
                    dlg = None
                    try:
                        dlg = chatoverlay.ChatOverlay(sess, _history_img(sess.slug))
                        overlay['dlg'] = dlg
                        overlay['slug'] = sess.slug
                        dlg.doModal()
                    except Exception:
                        pass
                    if dlg is not None and dlg.closed_by_user:
                        _chat_set_wanted(False)  # Back = chat off
                    overlay['dlg'] = None

                threading.Thread(target=_show, daemon=True).start()
        except Exception:
            pass
        # Heads-up display: room info strip (in-room toggle only) and the
        # discreet corner toast. Modeless windows — focus never moves.
        try:
            pslug = None
            if player.isPlayingVideo():
                pslug = chatclient.slug_from_playing_file(player.getPlayingFile() or '')
            if pslug and _flag(INFO_STATE_FILE):
                if hud_state['strip'] is None or hud_state['strip_slug'] != pslug:
                    text = pslug
                    d = chatclient.fetch_dossier(pslug)
                    if d:
                        subj = (d.get('room_subject') or d.get('subject') or '').strip()
                        if subj:
                            text = '%s  —  %s' % (pslug, subj)
                    if hud_state['strip'] is None:
                        hud_state['strip'] = hud.InfoStrip()
                        hud_state['strip'].show()
                    hud_state['strip'].set_text(text)
                    hud_state['strip_slug'] = pslug
                    hud_state['strip_text'] = text
            elif hud_state['strip'] is not None:
                hud_state['strip'].close()
                hud_state['strip'] = None
                hud_state['strip_slug'] = None
            if PENDING_TOASTS and hud_state['toast'] is None:
                hud_state['toast'] = hud.AlertToast()
                hud_state['toast'].set_text(PENDING_TOASTS.pop(0))
                hud_state['toast'].show()
                hud_state['toast_until'] = time.time() + 6
            if hud_state['toast'] is not None and time.time() > hud_state['toast_until']:
                hud_state['toast'].close()
                hud_state['toast'] = None
        except Exception:
            pass
        if _setting('alerts_enable') == 'true':
            minutes = 10
            if time.time() - last_check >= max(2, minutes) * 60:
                last_check = time.time()
                try:
                    check_alerts(state)
                except Exception:
                    pass
        if monitor.waitForAbort(5):
            break
    try:
        server.shutdown()
    except Exception:
        pass


if __name__ == '__main__':
    main()
