import os, shutil, zipfile, json, time
import xbmc, xbmcvfs

HOME = xbmcvfs.translatePath('special://home/')
ADDONS = os.path.join(HOME, 'addons')
DL = '/storage/emulated/0/Download'
STATUS = os.path.join(DL, 'jfn-clone-status.txt')
SKIN_ID = 'skin.arctic.fuse.2.jfn'
SKIN_ZIP_LOCAL = os.path.join(DL, 'skin.arctic.fuse.2.jfn-2.12.18.zip')
SKIN_URL = 'https://lyra-scratch.github.io/jfn-skin/skin.arctic.fuse.2.jfn-2.12.18.zip'
SNAP = os.path.join(DL, 'jfn-clone')

def status(msg):
    try:
        with open(STATUS, 'a') as f:
            f.write('%s %s\n' % (time.strftime('%H:%M:%S'), msg))
    except Exception:
        pass
    xbmc.log('JFNCLONE: ' + msg, xbmc.LOGINFO)

def rpc(payload):
    return json.loads(xbmc.executeJSONRPC(json.dumps(payload)))

def skin_installed():
    r = rpc({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.GetAddonDetails',
             'params': {'addonid': SKIN_ID, 'properties': ['version']}})
    try:
        return r['result']['addon']['version']
    except Exception:
        return None

def do_skin():
    if skin_installed():
        status('skin already present: %s' % skin_installed())
        return
    src = SKIN_ZIP_LOCAL
    if not os.path.exists(src):
        status('downloading skin zip')
        import urllib.request
        urllib.request.urlretrieve(SKIN_URL, src)
    target = os.path.join(ADDONS, SKIN_ID)
    if os.path.isdir(target):
        shutil.rmtree(target, ignore_errors=True)
    status('extracting skin')
    with zipfile.ZipFile(src) as z:
        z.extractall(ADDONS)
    xbmc.executebuiltin('UpdateLocalAddons')
    for i in range(30):
        xbmc.sleep(1000)
        v = skin_installed()
        if v:
            status('skin registered: %s' % v)
            rpc({'jsonrpc': '2.0', 'id': 2, 'method': 'Settings.SetSettingValue',
                 'params': {'setting': 'lookandfeel.skin', 'value': SKIN_ID}})
            status('skin set active')
            return
    status('ERROR: skin did not register')

def ignore_factory(skip_names):
    def ig(dirpath, names):
        return [n for n in names if n in skip_names]
    return ig

def do_snapshot():
    if os.path.isdir(SNAP):
        shutil.rmtree(SNAP, ignore_errors=True)
    os.makedirs(SNAP)
    total = 0
    for top in ('addons', 'userdata', 'media', 'system'):
        srcdir = os.path.join(HOME, top)
        if not os.path.isdir(srcdir):
            continue
        status('copying %s' % top)
        skip = {'packages'} if top == 'addons' else set()
        dest_top = os.path.join(SNAP, top)
        errs = 0
        for root, dirs, files in os.walk(srcdir):
            dirs[:] = [d for d in dirs if d not in skip]
            rel = os.path.relpath(root, srcdir)
            destdir = dest_top if rel == '.' else os.path.join(dest_top, rel)
            try:
                os.makedirs(destdir, exist_ok=True)
            except Exception:
                pass
            for fn in files:
                sp = os.path.join(root, fn)
                dp = os.path.join(destdir, fn)
                try:
                    if os.path.exists(dp):
                        try:
                            os.chmod(dp, 0o644)
                        except Exception:
                            pass
                    shutil.copyfile(sp, dp)
                    total += os.path.getsize(dp)
                except Exception:
                    errs += 1
        status('copied %s (running total %d bytes, %d files skipped)' % (top, total, errs))
    with open(os.path.join(SNAP, 'DONE.txt'), 'w') as f:
        f.write('total %d\n' % total)
    status('SNAPSHOT DONE total=%d' % total)

try:
    with open(STATUS, 'w') as f:
        f.write('')
    status('start')
    do_skin()
    do_snapshot()
    status('ALL DONE')
except Exception as e:
    status('FAILED: %r' % (e,))
