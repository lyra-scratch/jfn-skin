import xbmc, xbmcgui, xbmcvfs, os

def copy_one(src, dst):
    try:
        if xbmcvfs.exists(src):
            ok = xbmcvfs.copy(src, dst)
            return 'copied' if ok else 'copy returned false'
        return 'not found'
    except Exception as e:
        return 'error: %s' % e

results = []
for src, dst in [
    ('special://logpath/kodi.log', '/storage/emulated/0/Download/kodi.log'),
    ('special://logpath/kodi.old.log', '/storage/emulated/0/Download/kodi.old.log'),
]:
    results.append(os.path.basename(dst) + ': ' + copy_one(src, dst))
xbmcgui.Dialog().notification('JFN Log Helper', ' | '.join(results), xbmcgui.NOTIFICATION_INFO, 6000)
