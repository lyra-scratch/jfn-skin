# Chat transport for the add-on service (stage 2).
#
# Shape of the problem (probes/CHAT-PROBE.md): the site's chat rides a hosted
# realtime service with session-issued tokens. This module is deliberately
# SELF-DIAGNOSING: the token attempt traces the response SHAPE (status, key
# names, capability map) and the first raw stream events' key sets — never
# token values, never message contents — so the first on-box run produces
# the evidence the overlay is then tuned to.
import json
import re
import threading
import time
from collections import deque
from urllib.parse import urljoin, quote

import camsite

BASE = 'https://chaturbate.com'
PUSH_HOST = 'realtime.pa.highwebmedia.com'
TRACE = lambda m: None  # service wires this to xbmc.log
SEND_ENABLED = False  # the service re-asserts this every loop; send stays off

_DOSSIER_RE = re.compile(r'window\.initialRoomDossier = ("(?:[^"\\]|\\.)*")')


def fetch_dossier(slug):
    """Room page (with the add-on's session) -> parsed initialRoomDossier."""
    try:
        body = camsite.http(BASE + '/' + slug + '/')
    except Exception as exc:
        TRACE('chat dossier EXC slug=%s %s' % (slug, type(exc).__name__))
        return None
    m = _DOSSIER_RE.search(body or '')
    if not m:
        TRACE('chat dossier MISS slug=%s (no embedded dossier)' % slug)
        return None
    try:
        d = json.loads(json.loads(m.group(1)))
    except Exception as exc:
        TRACE('chat dossier PARSE-EXC slug=%s %s' % (slug, type(exc).__name__))
        return None
    TRACE('chat dossier slug=%s room_uid=%s asp_auth_url=%s keys=%d' % (
        slug, d.get('room_uid'), d.get('asp_auth_url'), len(d)))
    return d


def fetch_presence_id(slug):
    """The room page's inline push config carries a presence id; the auth
    call wants it prefixed '-' (non-primary) or '+' (primary)."""
    try:
        body = camsite.http(BASE + '/' + slug + '/')
    except Exception:
        return None
    m = (re.search(r'"presence_id"\s*:\s*"([^"]+)"', body or '')
         or re.search(r"presence_id:\s*'([^']+)'", body or ''))
    if m and m.group(1) and m.group(1) != 'None':
        return '-' + m.group(1)
    return None


def request_push_auth(room_uid, presence_id=None):
    """The site's real chat auth (reverse-engineered from its own client
    and proven live 2026-11-13): POST /push_service/auth/ with the room
    message topic -> {token: JWT, channels: {topic: channel}}. The
    dossier's asp_auth_url is the broadcaster app portal (an HTML page),
    NOT viewer chat auth — the old token attempt died there."""
    import urllib.parse
    topics = json.dumps({'RoomMessageTopic#%s' % room_uid:
                         {'broadcaster_uid': room_uid}})
    form = {
        'presence_id': presence_id or '-anon',
        'topics': topics,
        'backend': 'a'}
    try:
        raw = camsite.http(BASE + '/push_service/auth/', data=form,
                           headers={'X-Requested-With': 'XMLHttpRequest'},
                           timeout=20)
        d = json.loads(raw)
    except Exception as exc:
        TRACE('chat push-auth EXC %s %s' % (type(exc).__name__, str(exc)[:140]))
        return None
    if not isinstance(d, dict):
        return None
    token = d.get('token')
    channels = d.get('channels') or {}
    channel = next(iter(channels.values()), None)
    settings = d.get('settings') or {}
    host = settings.get('host') or PUSH_HOST
    cap = (d.get('token_request') or {}).get('capability')
    TRACE('chat push-auth token=%s channel=%s host=%s presence=%s failures=%s' % (
        'yes' if token else 'NO', channel, host,
        'real' if (presence_id and presence_id != '-anon') else 'anon',
        list((d.get('failures') or {}).values())))
    if not token or not channel:
        return None
    return {'token': token, 'channel': channel, 'host': host,
            'capability': cap}


class ChatBuffer:
    """Bounded, thread-safe message buffer the overlay polls."""

    def __init__(self, maxlen=200):
        self._d = deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._seq = 0

    def add(self, msg):
        with self._lock:
            self._seq += 1
            msg = dict(msg)
            msg['seq'] = self._seq
            self._d.append(msg)

    def since(self, seq):
        with self._lock:
            return [m for m in self._d if m['seq'] > seq]

    def __len__(self):
        with self._lock:
            return len(self._d)


def _rgb_to_hex(value):
    m = re.match(r'rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)',
                 value or '')
    if not m:
        return ''
    return '#%02x%02x%02x' % (int(m.group(1)), int(m.group(2)),
                              int(m.group(3)))


def normalize_event(evt, trace_shapes):
    """One realtime event -> a chat line dict, or None. Live shape
    (captured 2026-11-13): the SSE envelope's data is a JSON string whose
    payload carries _topic; RoomMessageTopic payloads hold from_user
    {username,...}, message, font_color 'rgb(r,g,b)'. Other topics
    (RoomUpdateTopic pings etc.) are not chat lines."""
    if not isinstance(evt, dict):
        return None
    data = evt.get('data')
    name = evt.get('name') or ''
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except Exception:
            return {'user': '', 'text': data, 'kind': name or 'message'}
    if not isinstance(data, dict):
        return None
    topic = data.get('_topic')
    if topic is not None and topic != 'RoomMessageTopic':
        return None
    user = ''
    fu = data.get('from_user')
    if isinstance(fu, dict):
        user = fu.get('username') or ''
    elif isinstance(fu, str):
        user = fu
    if not user:
        user = (data.get('from_username') or data.get('username')
                or data.get('user') or data.get('sender') or '')
    text = data.get('message') or data.get('text') or data.get('msg') or ''
    if not text:
        return None
    color = _rgb_to_hex(data.get('font_color'))
    if not color:
        raw = data.get('color') or ''
        color = raw if re.match(r'^#[0-9a-fA-F]{6}$', raw or '') else ''
    return {'user': user, 'text': text, 'kind': 'message', 'color': color}


class SSEChat(threading.Thread):
    """Consumes the push SSE stream for one channel into a ChatBuffer.
    On stream end it re-auths (JWTs expire) and reconnects while the
    session lives."""

    def __init__(self, channel, token, buffer, host=PUSH_HOST,
                 refresh=None):
        super().__init__(daemon=True)
        self.channel = channel
        self.token = token
        self.buffer = buffer
        self.host = host
        self.refresh = refresh
        self.stopping = False
        self.shapes = []
        self._resp = None
        self.census = {}

    def stop(self):
        self.stopping = True
        if self._resp is not None:
            try:
                self._resp.close()
            except Exception:
                pass

    def run(self):
        tries = 0
        while not self.stopping and tries < 12:
            tries += 1
            try:
                self._run_once()
            except Exception as exc:
                if not self.stopping:
                    TRACE('chat sse EXC %s' % type(exc).__name__)
            if self.stopping:
                return
            if self.refresh is not None:
                fresh = self.refresh()
                if fresh:
                    self.token, self.channel, self.host = fresh
            import time as _t
            _t.sleep(3)

    def _run_once(self):
        url = 'https://%s/sse?v=1.2&channels=%s' % (
            self.host, quote(self.channel, safe=''))
        TRACE('chat sse open channel=%s host=%s' % (self.channel, self.host))
        import urllib.request
        req = urllib.request.Request(url, headers={
            'Authorization': 'Bearer ' + self.token,
            'Accept': 'text/event-stream',
            'User-Agent': camsite.UA_BROWSER,
        })
        opener = urllib.request.build_opener()
        # The push service flushes chat in lazy batches; a short read
        # timeout hangs up before the first batch ever lands (measured:
        # messages arrived on a patient connection, never on 30s ones).
        # Long leash here; stop() closes the socket to unblock the read.
        with opener.open(req, timeout=300) as resp:
            self._resp = resp
            TRACE('chat sse status=%s' % resp.status)
            try:
                self._consume(resp)
            finally:
                self._resp = None
                TRACE('chat sse census topics=%r buffered=%d' % (
                    self.census, len(self.buffer)))

    def _consume(self, resp):
        data_lines = []
        for raw in resp:
            if self.stopping:
                return
            line = raw.decode('utf-8', 'replace').rstrip('\r\n')
            if line.startswith('data:'):
                data_lines.append(line[5:].lstrip())
            elif line == '':
                if data_lines:
                    self._emit('\n'.join(data_lines))
                    data_lines = []
            # ':' comment lines are heartbeats — ignored by design

    def _emit(self, payload):
        try:
            evt = json.loads(payload)
        except Exception:
            return
        data = evt.get('data') if isinstance(evt, dict) else None
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except Exception:
                data = None
        topic = data.get('_topic') if isinstance(data, dict) else 'envelope'
        self.census[topic] = self.census.get(topic, 0) + 1
        msg = normalize_event(evt, self.shapes)
        if msg:
            self.buffer.add(msg)


ACTIVE_SESSION = None  # service sets this; the overlay reads it


def slug_from_playing_file(path):
    """'http://127.0.0.1:57711/play/<slug>.m3u8' -> '<slug>', else None."""
    if not path or '/play/' not in path:
        return None
    tail = path.split('/play/', 1)[1]
    slug = tail.split('.m3u8', 1)[0].strip('/')
    return slug or None


class ChatSession:
    """One room's chat: dossier -> token -> stream. start() is best-effort
    and fully traced; every failure mode lands in the trace, not the UI."""

    def __init__(self, slug):
        self.slug = slug
        self.buffer = ChatBuffer()
        self.stream = None
        self.channel = None
        self.token = None
        self.capability = None
        self.viewer = ''
        self.dossier = None
        self.host = PUSH_HOST

    # send is gated twice: the token's capability must allow publish on the
    # channel, and the service must have enabled it from settings. The first
    # gated-on run's response is traced so the payload shape is confirmed
    # on evidence before it is relied on.

    def start(self):
        dossier = fetch_dossier(self.slug)
        if not dossier or not dossier.get('room_uid'):
            TRACE('chat session slug=%s no dossier/room_uid' % self.slug)
            return False
        self.dossier = dossier
        self.viewer = dossier.get('viewer_username') or ''
        auth = request_push_auth(dossier['room_uid'],
                                 fetch_presence_id(self.slug))
        if not auth:
            TRACE('chat session slug=%s no token - stream not started'
                  % self.slug)
            return False
        self.token = auth['token']
        self.capability = auth.get('capability')
        self.channel = auth['channel']
        self.host = auth['host']
        self.stream = SSEChat(self.channel, self.token, self.buffer,
                              host=self.host, refresh=self._refresh)
        self.stream.start()
        return True

    def _refresh(self):
        if not getattr(self, 'dossier', None):
            return None
        auth = request_push_auth(self.dossier['room_uid'],
                                 fetch_presence_id(self.slug))
        if not auth:
            return None
        self.token = auth['token']
        self.capability = auth.get('capability')
        return auth['token'], auth['channel'], auth['host']

    def stop(self):
        if self.stream is not None:
            self.stream.stop()


def send_message(session, text):
    """Publish one chat line. Returns True only on a 2xx from the realtime
    REST endpoint; every refusal is traced with its reason."""
    if not SEND_ENABLED:
        TRACE('chat send HELD (send not enabled in settings) slug=%s' % session.slug)
        return False
    if not session or not session.token or not session.channel:
        TRACE('chat send FAIL (no live session)')
        return False
    ops = _capability_ops(session.capability, session.channel)
    if 'publish' not in ops and '*' not in ops:
        TRACE('chat send FAIL (capability has no publish: %r)' % (ops,))
        return False
    import urllib.request
    import urllib.error
    url = 'https://%s/channels/%s/messages' % (getattr(session, 'host', PUSH_HOST), quote(session.channel, safe=''))
    payload = json.dumps({'name': 'message', 'data': {
        'username': session.viewer, 'message': text}}).encode('utf-8')
    req = urllib.request.Request(url, data=payload, method='POST', headers={
        'Authorization': 'Bearer ' + session.token,
        'Content-Type': 'application/json',
        'User-Agent': camsite.UA_BROWSER,
    })
    try:
        with urllib.request.build_opener().open(req, timeout=15) as resp:
            TRACE('chat send status=%s slug=%s' % (resp.status, session.slug))
            return 200 <= resp.status < 300
    except urllib.error.HTTPError as e:
        TRACE('chat send HTTP %s slug=%s' % (e.code, session.slug))
    except Exception as exc:
        TRACE('chat send EXC %s' % type(exc).__name__)
    return False
