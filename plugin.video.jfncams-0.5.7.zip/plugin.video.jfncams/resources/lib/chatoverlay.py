# Chat overlay window (stage 2) — runs in the service process.
#
# A right-side panel over the playing video: recent chat lines, a Type
# button (the phone remote's keyboard feeds Kodi's input dialog), and
# player keys forwarded so watching still works while it is open. Back
# closes it; the service keeps it closed for that room afterwards.
import os
import re
import threading
import time

import xbmc
import xbmcgui

import chatclient

_ADDON_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))))
_BG_PATH = os.path.join(_ADDON_ROOT, 'resources', 'media', 'panel_bg.png')
_BTN_PATH = os.path.join(_ADDON_ROOT, 'resources', 'media', 'type_btn.png')
_BTN_FOCUS_PATH = os.path.join(_ADDON_ROOT, 'resources', 'media',
                               'type_btn_focus.png')

# 1280x720 design space
PANEL_X, PANEL_Y, PANEL_W, PANEL_H = 830, 60, 420, 560
LINE_COUNT = 16

ACTION_NAV_BACK = 92
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_PAUSE = 12
ACTION_STOP = 13
ACTION_PLAY = 68
ACTION_STEP_FORWARD = 21
ACTION_STEP_BACK = 22
ACTION_BIG_STEP_FORWARD = 23
ACTION_BIG_STEP_BACK = 24
ACTION_CONTEXT_MENU = 117
ACTION_SHOW_OSD = 163


_HEX = re.compile(r'^#[0-9a-fA-F]{6}$')


def format_lines(messages, width_user=14):
    """Buffer messages -> display lines, newest last. Pure; unit-tested.
    A sender colour from the site (plain #RRGGBB only) colours the name."""
    out = []
    for m in messages[-LINE_COUNT:]:
        user = (m.get('user') or '').strip()
        text = (m.get('text') or '').replace('\n', ' ').strip()
        if not text:
            continue
        if user:
            color = m.get('color') or ''
            if _HEX.match(color):
                out.append('[B][COLOR %s]%s[/COLOR]:[/B] %s' % (color, user[:width_user], text))
            else:
                out.append('[B]%s:[/B] %s' % (user[:width_user], text))
        else:
            out.append(text)
    return out


class ChatOverlay(xbmcgui.WindowDialog):
    def __init__(self, session, img='', info_lines=None):
        super().__init__()
        self.session = session
        self._img = img
        self._info = [l for l in (info_lines or []) if l][:2]
        self.closed_by_user = False
        self.menu_requested = False
        self._last_seq = 0
        self._stop = threading.Event()
        self._bg = xbmcgui.ControlImage(PANEL_X, PANEL_Y, PANEL_W, PANEL_H,
                                        _BG_PATH)
        title_x = PANEL_X + 14
        self._thumb = None
        if self._img:
            self._thumb = xbmcgui.ControlImage(PANEL_X + 14, PANEL_Y + 10, 56, 32, self._img)
            title_x = PANEL_X + 80
        self._title = xbmcgui.ControlLabel(title_x, PANEL_Y + 8, PANEL_W - (title_x - PANEL_X) - 14, 30,
                                           '', textColor='FF4CD7E6')
        body_y = PANEL_Y + 44
        info_ctls = []
        for line in self._info:
            info_ctls.append(xbmcgui.ControlLabel(
                PANEL_X + 14, body_y - 4, PANEL_W - 28, 22, line,
                textColor='FFB9C4CC', font='font10'))
            body_y += 24
        self._body = xbmcgui.ControlTextBox(PANEL_X + 14, body_y,
                                            PANEL_W - 28,
                                            PANEL_H - (body_y - PANEL_Y) - 56,
                                            font='font12',
                                            textColor='FFF2F5F8')
        self._type_btn = xbmcgui.ControlButton(
            PANEL_X + 14, PANEL_Y + PANEL_H - 48, PANEL_W - 28, 36,
            'Type a message', focusTexture=_BTN_FOCUS_PATH,
            noFocusTexture=_BTN_PATH, textColor='FFD7DEE6',
            focusedColor='FF4CD7E6')
        controls = [self._bg, self._title] + info_ctls + [self._body, self._type_btn]
        if self._thumb is not None:
            controls.insert(1, self._thumb)
        self.addControls(controls)
        self.setFocus(self._type_btn)

    def onInit(self):
        self._title.setLabel('Chat — %s' % self.session.slug)
        self._body.setText(
            '[COLOR FF8899AA]Listening for chat...[/COLOR]')
        t = threading.Thread(target=self._refresh_loop, daemon=True)
        t.start()

    def _refresh_loop(self):
        last_count = -1
        traced_error = False
        while not self._stop.is_set():
            try:
                msgs = self.session.buffer.since(0)
                lines = format_lines(msgs)
                if lines:
                    self._body.setText('\n'.join(lines))
                else:
                    self._body.setText(
                        '[COLOR FF8899AA]Listening for chat...[/COLOR]')
                if len(lines) != last_count:
                    last_count = len(lines)
                    chatclient.TRACE('chat overlay lines=%d buffered=%d' % (
                        len(lines), len(msgs)))
            except Exception as e:
                if not traced_error:
                    traced_error = True
                    chatclient.TRACE('chat overlay refresh error: %r' % (e,))
            self._stop.wait(1.0)

    def onClick(self, controlId):
        if controlId == self._type_btn.getId():
            text = xbmcgui.Dialog().input('Message to %s' % self.session.slug,
                                          type=xbmcgui.INPUT_ALPHANUM)
            if text:
                if not chatclient.send_message(self.session, text):
                    viewer = getattr(self.session, 'viewer', '') or ''
                    if not viewer or viewer == 'AnonymousUser':
                        note = 'Log in to send chat'
                    else:
                        note = 'Message not sent'
                    xbmcgui.Dialog().notification(
                        'Chat', note, xbmcgui.NOTIFICATION_INFO, 3000)

    def onAction(self, action):
        aid = action.getId()
        if aid in (ACTION_CONTEXT_MENU, ACTION_SHOW_OSD):
            # The remote's Menu key belongs to the in-room panel. The
            # overlay must hand it over, not swallow it: close WITHOUT
            # marking a user close (chat stays on) and let the service
            # open the panel.
            self.menu_requested = True
            self.close()
            return
        if aid in (ACTION_NAV_BACK, ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU):
            self.closed_by_user = True
            self.close()
            return
        player = xbmc.Player()
        if aid == ACTION_PAUSE:
            player.pause()
        elif aid == ACTION_PLAY:
            player.play()
        elif aid == ACTION_STOP:
            player.stop()
            self.close()
        elif aid in (ACTION_STEP_FORWARD, ACTION_BIG_STEP_FORWARD):
            player.seekTime(min(player.getTime() + 10, 10 ** 9))
        elif aid in (ACTION_STEP_BACK, ACTION_BIG_STEP_BACK):
            player.seekTime(max(player.getTime() - 10, 0))
        else:
            super().onAction(action)

    def close(self):
        self._stop.set()
        try:
            super().close()
        except Exception:
            pass
