# Heads-up windows (build B): the room info strip and the discreet alert
# toast. Both are MODELESS xbmcgui.Window objects — they never take focus,
# so the Fire remote keeps driving the video while they are on screen.
import xbmcgui


class InfoStrip(xbmcgui.Window):
    """One slim bar across the top: room name + subject."""

    def __init__(self):
        super().__init__()
        self._bg = xbmcgui.ControlImage(0, 0, 1280, 52, '', colorDiffuse='B30B0E1A')
        self._label = xbmcgui.ControlLabel(16, 12, 1248, 30, '', textColor='FFFFFFFF')
        self.addControls([self._bg, self._label])

    def set_text(self, text):
        self._label.setLabel(text)


class AlertToast(xbmcgui.Window):
    """Small lower-right corner note — Chad asked for discreet, not Kodi's
    full notification banner."""

    def __init__(self):
        super().__init__()
        self._bg = xbmcgui.ControlImage(896, 596, 368, 64, '', colorDiffuse='CC0B0E1A')
        self._label = xbmcgui.ControlLabel(912, 614, 336, 32, '', textColor='FF4CD7E6')
        self.addControls([self._bg, self._label])

    def set_text(self, text):
        self._label.setLabel(text)
