# Chat transport for the add-on service (stage 2).
#
# Shape of the problem (probes/CHAT-PROBE.md): the site's chat rides a hosted
# realtime service with session-issued tokens. This module is deliberately
# SELF-DIAGNOSING: the token attempt traces the response SHAPE (status, key
# names, capability map) and the first raw stream events' key sets — never
# token values, never message contents — so the first on-box run produces
# the evidence the overlay is then tuned to.
import json
import re
import threading
import time
from collections import deque
from urllib.parse import urljoin, quote

import camsite

BASE = 'https://chaturbate.com'
ABLY_SSE = 'https://realtime.ably.io/sse'
TRACE = lambda m: None  # service wires this to xbmc.log

_DOSSIER_RE = re.compile(r'window\.initialRoomDossier = ("(?:[^"\\]|\\.)*")')


def fetch_dossier(slug):
    """Room page (with the add-on's session) -> parsed initialRoomDossier."""
    try:
        body = camsite.http(BASE + '/' + slug + '/')
    except Exception as exc:
        TRACE('chat dossier EXC slug=%s %s' % (slug, type(exc).__name__))
        return None
    m = _DOSSIER_RE.search(body or '')
    if not m:
        TRACE('chat dossier MISS slug=%s (no embedded dossier)' % slug)
        return None
    try:
        d = json.loads(json.loads(m.group(1)))
    except Exception as exc:
        TRACE('chat dossier PARSE-EXC slug=%s %s' % (slug, type(exc).__name__))
        return None
    TRACE('chat dossier slug=%s room_uid=%s asp_auth_url=%s keys=%d' % (
        slug, d.get('room_uid'), d.get('asp_auth_url'), len(d)))
    return d


def request_token(dossier):
    """One token attempt against the dossier's auth URL. Returns a dict:
    {token, capability, raw_keys} on success, else None. The token VALUE is
    never traced; the capability map (channel names + ops) is."""
    auth = (dossier or {}).get('asp_auth_url')
    if not auth:
        TRACE('chat token SKIP (no asp_auth_url in dossier)')
        return None
    url = urljoin(BASE, auth)
    try:
        status, headers, body = camsite.http_full(url)
    except Exception as exc:
        TRACE('chat token EXC %s' % type(exc).__name__)
        return None
    ctype = headers.get('Content-Type', '')
    TRACE('chat token status=%s ctype=%s bytes=%d' % (status, ctype, len(body or b'')))
    cap_hdr = headers.get('x-ably-capability') or headers.get('X-Ably-Capability')
    if cap_hdr:
        TRACE('chat token capability(header)=%s' % cap_hdr[:300])
    if status != 200 or not body:
        return None
    try:
        d = json.loads(body.decode('utf-8', 'replace'))
    except Exception:
        TRACE('chat token body NOT-JSON (first bytes %r)' % (body[:40],))
        return None
    if isinstance(d, dict):
        TRACE('chat token json keys=%s' % sorted(d.keys()))
        cap = d.get('capability')
        if cap:
            TRACE('chat token capability(body)=%s' % str(cap)[:300])
        token = d.get('token') or d.get('id')
        if isinstance(token, str) and token:
            return {'token': token, 'capability': cap, 'raw_keys': sorted(d.keys())}
        # Ably TokenDetails shape: {keyName, ttl, capability, ...} with the
        # token itself in 'token' — absent here means this endpoint answered
        # something else (e.g. a TokenRequest, which cannot be used as-is).
        TRACE('chat token NO-TOKEN-FIELD (endpoint answered a different shape)')
    return None


class ChatBuffer:
    """Bounded, thread-safe message buffer the overlay polls."""

    def __init__(self, maxlen=200):
        self._d = deque(maxlen=maxlen)
        self._lock = threading.Lock()
        self._seq = 0

    def add(self, msg):
        with self._lock:
            self._seq += 1
            msg = dict(msg)
            msg['seq'] = self._seq
            self._d.append(msg)

    def since(self, seq):
        with self._lock:
            return [m for m in self._d if m['seq'] > seq]

    def __len__(self):
        with self._lock:
            return len(self._d)


def normalize_event(evt, trace_shapes):
    """One realtime event -> a chat line dict, or None for non-chat events.
    Shape-tolerant on purpose; the first few raw shapes are traced so the
    mapping can be tightened on evidence, not guesses."""
    if not isinstance(evt, dict):
        return None
    data = evt.get('data')
    name = evt.get('name') or ''
    if trace_shapes is not None and len(trace_shapes) < 3:
        shape = 'name=%r data=%s' % (
            name, sorted(data.keys()) if isinstance(data, dict) else type(data).__name__)
        if shape not in trace_shapes:
            trace_shapes.append(shape)
            TRACE('chat event shape %s' % shape)
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except Exception:
            return {'user': '', 'text': data, 'kind': name or 'message'}
    if not isinstance(data, dict):
        return None
    user = data.get('username') or data.get('user') or data.get('sender') or ''
    text = data.get('message') or data.get('text') or data.get('msg') or ''
    if not text:
        return None
    return {'user': user, 'text': text, 'kind': name or 'message',
            'color': data.get('color') or data.get('font_color') or ''}


class SSEChat(threading.Thread):
    """Consumes the realtime SSE stream for one channel into a ChatBuffer."""

    def __init__(self, channel, token, buffer):
        super().__init__(daemon=True)
        self.channel = channel
        self.token = token
        self.buffer = buffer
        self.stopping = False
        self.shapes = []

    def stop(self):
        self.stopping = True

    def run(self):
        url = '%s?v=1.2&channels=%s' % (ABLY_SSE, quote(self.channel, safe=''))
        TRACE('chat sse open channel=%s' % self.channel)
        try:
            import urllib.request
            req = urllib.request.Request(url, headers={
                'Authorization': 'Bearer ' + self.token,
                'Accept': 'text/event-stream',
                'User-Agent': camsite.UA_BROWSER,
            })
            opener = urllib.request.build_opener()
            with opener.open(req, timeout=30) as resp:
                TRACE('chat sse status=%s' % resp.status)
                self._consume(resp)
        except Exception as exc:
            TRACE('chat sse EXC %s' % type(exc).__name__)

    def _consume(self, resp):
        data_lines = []
        for raw in resp:
            if self.stopping:
                return
            line = raw.decode('utf-8', 'replace').rstrip('\r\n')
            if line.startswith('data:'):
                data_lines.append(line[5:].lstrip())
            elif line == '':
                if data_lines:
                    self._emit('\n'.join(data_lines))
                    data_lines = []
            # ':' comment lines are heartbeats — ignored by design

    def _emit(self, payload):
        try:
            evt = json.loads(payload)
        except Exception:
            return
        msg = normalize_event(evt, self.shapes)
        if msg:
            self.buffer.add(msg)


ACTIVE_SESSION = None  # service sets this; the overlay reads it


def slug_from_playing_file(path):
    """'http://127.0.0.1:57711/play/<slug>.m3u8' -> '<slug>', else None."""
    if not path or '/play/' not in path:
        return None
    tail = path.split('/play/', 1)[1]
    slug = tail.split('.m3u8', 1)[0].strip('/')
    return slug or None


class ChatSession:
    """One room's chat: dossier -> token -> stream. start() is best-effort
    and fully traced; every failure mode lands in the trace, not the UI."""

    def __init__(self, slug):
        self.slug = slug
        self.buffer = ChatBuffer()
        self.stream = None
        self.channel = None
        self.token = None
        self.capability = None
        self.viewer = ''

    # send is gated twice: the token's capability must allow publish on the
    # channel, and the service must have enabled it from settings. The first
    # gated-on run's response is traced so the payload shape is confirmed
    # on evidence before it is relied on.

    def start(self):
        dossier = fetch_dossier(self.slug)
        if not dossier:
            return False
        tok = request_token(dossier)
        if not tok:
            TRACE('chat session slug=%s no token — stream not started' % self.slug)
            return False
        self.token = tok['token']
        self.capability = tok.get('capability')
        self.viewer = dossier.get('viewer_username') or ''
        cap = self.capability
        channel = pick_channel(cap, dossier)
        if not channel:
            TRACE('chat session slug=%s no channel in capability=%r' % (self.slug, cap))
            return False
        self.channel = channel
        self.stream = SSEChat(channel, self.token, self.buffer)
        self.stream.start()
        return True

    def stop(self):
        if self.stream:
            self.stream.stop()


def pick_channel(capability, dossier):
    """The capability map names the channels outright. Prefer one that
    mentions the room; else the first subscribable channel."""
    if isinstance(capability, str):
        try:
            capability = json.loads(capability)
        except Exception:
            capability = None
    if isinstance(capability, dict) and capability:
        room_uid = (dossier or {}).get('room_uid') or ''
        for name, ops in capability.items():
            if room_uid and room_uid in name:
                return name
        for name, ops in capability.items():
            if isinstance(ops, list) and ('subscribe' in ops or '*' in ops):
                return name
        return next(iter(capability))
    return None


SEND_ENABLED = False  # service sets from the chat_send_enable setting


def _capability_ops(capability, channel):
    if isinstance(capability, str):
        try:
            capability = json.loads(capability)
        except Exception:
            return []
    if isinstance(capability, dict):
        ops = capability.get(channel) or capability.get('*') or []
        return ops if isinstance(ops, list) else []
    return []


def send_message(session, text):
    """Publish one chat line. Returns True only on a 2xx from the realtime
    REST endpoint; every refusal is traced with its reason."""
    if not SEND_ENABLED:
        TRACE('chat send HELD (send not enabled in settings) slug=%s' % session.slug)
        return False
    if not session or not session.token or not session.channel:
        TRACE('chat send FAIL (no live session)')
        return False
    ops = _capability_ops(session.capability, session.channel)
    if 'publish' not in ops and '*' not in ops:
        TRACE('chat send FAIL (capability has no publish: %r)' % (ops,))
        return False
    import urllib.request
    import urllib.error
    url = 'https://rest.ably.io/channels/%s/messages' % quote(session.channel, safe='')
    payload = json.dumps({'name': 'message', 'data': {
        'username': session.viewer, 'message': text}}).encode('utf-8')
    req = urllib.request.Request(url, data=payload, method='POST', headers={
        'Authorization': 'Bearer ' + session.token,
        'Content-Type': 'application/json',
        'User-Agent': camsite.UA_BROWSER,
    })
    try:
        with urllib.request.build_opener().open(req, timeout=15) as resp:
            TRACE('chat send status=%s slug=%s' % (resp.status, session.slug))
            return 200 <= resp.status < 300
    except urllib.error.HTTPError as e:
        TRACE('chat send HTTP %s slug=%s' % (e.code, session.slug))
    except Exception as exc:
        TRACE('chat send EXC %s' % type(exc).__name__)
    return False
