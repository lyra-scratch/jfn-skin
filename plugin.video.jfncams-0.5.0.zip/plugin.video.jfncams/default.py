# JFN Cams 0.2.0 - browse, filters, login, favorites, history, top cams,
# and playback through the local relay (see resources/lib/relay.py for why).
# Stdlib only.
import sys, os, json, time
from urllib.parse import parse_qsl, urlencode, quote
from urllib.request import urlopen

import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_DIR, 'resources', 'lib'))

import camsite
import zaputil
import chatclient
import relay as relaymod

BASE = sys.argv[0]
try:
    HANDLE = int(sys.argv[1])
except Exception:
    HANDLE = -1
PARAMS = dict(parse_qsl(sys.argv[2].lstrip('?'))) if len(sys.argv) > 2 else {}

LIMIT = 60
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
camsite.init(PROFILE)
FAV_FILE = os.path.join(PROFILE, 'favorites.json')
HIST_FILE = os.path.join(PROFILE, 'history.json')
FILTER_FILE = os.path.join(PROFILE, 'filters.json')
ZAP_FILE = os.path.join(PROFILE, 'zap_context.json')
CHAT_STATE_FILE = os.path.join(PROFILE, 'chat_state.json')
INFO_STATE_FILE = os.path.join(PROFILE, 'info_state.json')
CATART_FILE = os.path.join(PROFILE, 'catart.json')

REGIONS = [('', 'Any region'), ('NA', 'North America'), ('SA', 'South America'),
           ('ER', 'Europe / Russia'), ('AS', 'Asia'), ('O', 'Other')]
AGES = [('', 'Any age'), ('18-19', '18-19'), ('20-30', '20-30'),
        ('30-50', '30-50'), ('50+', '50 and over')]
AGE_PARAMS = {'18-19': ('18', '19'), '20-30': ('20', '30'),
              '30-50': ('30', '50'), '50+': ('50', '200')}
SORTS = [('', 'Site order'), ('viewers', 'Most viewers'), ('followers', 'Most followers'),
         ('newest', 'Newest first')]


def notify(msg, heading='JFN Cams', ms=4500):
    xbmcgui.Dialog().notification(heading, msg, xbmcgui.NOTIFICATION_INFO, ms)


def plugin_url(params):
    return BASE + '?' + urlencode(params)


# ---------------- local stores ----------------

def _load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return default
    return default


def _save_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception:
        pass


def load_favs():
    return _load_json(FAV_FILE, [])


def fav_slugs():
    return [f.get('slug') for f in load_favs()]


def load_filters():
    f = _load_json(FILTER_FILE, {})
    return {'region': f.get('region', ''), 'age': f.get('age', ''),
            'tag': f.get('tag', ''), 'new_only': bool(f.get('new_only', False)),
            'sort': f.get('sort', '')}


def save_filters(f):
    _save_json(FILTER_FILE, f)


def filters_active(f):
    return bool(f['region'] or f['age'] or f['tag'] or f['new_only'])


def filters_summary(f):
    bits = []
    for code, label in REGIONS:
        if f['region'] == code and code:
            bits.append(label)
    if f['age']:
        bits.append('Age ' + f['age'])
    if f['tag']:
        bits.append('#' + f['tag'])
    if f['new_only']:
        bits.append('New only')
    for code, label in SORTS:
        if f['sort'] == code and code:
            bits.append(label)
    return ' · '.join(bits) if bits else 'Off'


def apply_filters(query, f):
    q = dict(parse_qsl(query))
    if f['region']:
        q['regions'] = f['region']
    if f['age'] in AGE_PARAMS:
        q['from_age'], q['to_age'] = AGE_PARAMS[f['age']]
    if f['tag']:
        q['hashtags'] = f['tag']
    if f['new_only']:
        q['new_cams'] = 'true'
    return urlencode(q)


def sort_rooms(rooms, f):
    if f['sort'] == 'viewers':
        return sorted(rooms, key=lambda r: r.get('num_users', 0), reverse=True)
    if f['sort'] == 'followers':
        return sorted(rooms, key=lambda r: r.get('num_followers', 0), reverse=True)
    if f['sort'] == 'newest':
        return sorted(rooms, key=lambda r: r.get('start_dt_utc', ''), reverse=True)
    return rooms


def record_history(slug, img):
    hist = _load_json(HIST_FILE, [])
    hist = [h for h in hist if h.get('slug') != slug]
    hist.insert(0, {'slug': slug, 'img': img, 'ts': int(time.time())})
    _save_json(HIST_FILE, hist[:50])


# ---------------- login ----------------

def ensure_login():
    if camsite.has_session_cookie() and camsite.logged_in_live():
        return True
    ok, msg = camsite.do_login(ADDON.getSetting('username').strip(),
                               ADDON.getSetting('password'))
    notify(msg)
    if not ok and 'settings first' in msg:
        ADDON.openSettings()
    return ok


# ---------------- rendering ----------------

def add_room(room, favs, back=''):
    slug = room.get('username', '')
    if not slug:
        return
    img = room.get('img', '')
    viewers = room.get('num_users', 0)
    followers = room.get('num_followers', 0)
    subject = (room.get('room_subject') or room.get('subject') or '').strip()
    loc = room.get('location') or room.get('country') or ''
    meta = 'Viewers: %s   Followers: %s' % (viewers, followers)
    if loc:
        meta += '   ' + loc
    plot = (subject + '\n' + meta) if subject else meta
    tags = room.get('tags') or []
    if tags:
        plot += '\n' + ' '.join('#' + t for t in tags[:8])
    status = room.get('current_show', 'public')
    playable = status == 'public'
    li = xbmcgui.ListItem(label=slug)
    li.setArt({'thumb': img, 'icon': img, 'fanart': img})
    li.setInfo('video', {'title': slug, 'plot': plot, 'mediatype': 'video'})
    menu = []
    if room.get('is_following'):
        menu.append(('Unfollow ' + slug, 'RunPlugin(%s)' % plugin_url({'mode': 'unfollow', 'slug': slug})))
    else:
        menu.append(('Follow ' + slug, 'RunPlugin(%s)' % plugin_url({'mode': 'follow', 'slug': slug})))
    if slug in favs:
        menu.append(('Remove from My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_del', 'slug': slug})))
    else:
        menu.append(('Add to My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_add', 'slug': slug, 'img': img})))
    # Filters live in the context menu too (Chad's placement ruling,
    # 2026-11-13): the listing's Filters row sorts to the bottom under
    # Fuse, so the menu is the reliable way in. Container.Update (not
    # RunPlugin) because the filters screen is a directory.
    menu.append(('Filters...', 'Container.Update(%s)' % plugin_url({'mode': 'filters', 'back': back})))
    for t in tags[:3]:
        menu.append(('More like this: #%s' % t, 'RunPlugin(%s)' % plugin_url({'mode': 'settag', 'tag': t})))
    li.addContextMenuItems(menu)
    if playable:
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'play', 'slug': slug, 'img': img, 'ctx': back}), li, False)
    else:
        li.setLabel(slug + '  [' + status + ']')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'offline', 'slug': slug, 'status': status}), li, False)


def filters_row(back_params):
    f = load_filters()
    label = 'Filters: %s  (tap to change)' % filters_summary(f)
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'filters', 'back': urlencode(back_params)}), li, True)


def list_rooms(query, title, filtered=True):
    xbmcplugin.setContent(HANDLE, 'videos')
    f = load_filters()
    if filtered:
        filters_row({'mode': 'list', 'query': query, 'title': title})
        query = apply_filters(query, f)
    try:
        rooms, total = camsite.api_rooms(query)
    except Exception as e:
        notify('Could not load rooms: %s' % e)
        rooms, total = [], 0
    rooms = sort_rooms(rooms, f)
    if rooms and rooms[0].get('img'):
        try:
            art = _load_json(CATART_FILE, {})
            if art.get(title) != rooms[0]['img']:
                art[title] = rooms[0]['img']
                _save_json(CATART_FILE, art)
        except Exception:
            pass
    favs = fav_slugs()
    for room in rooms:
        add_room(room, favs, urlencode({'mode': 'list', 'query': query, 'title': title}))
    q = dict(parse_qsl(query))
    offset = int(q.get('offset', '0'))
    if rooms and offset + len(rooms) < total:
        q['offset'] = str(offset + int(q.get('limit', str(LIMIT))))
        li = xbmcgui.ListItem(label='Next page >>')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'list', 'query': urlencode(q), 'title': title}), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def root_menu():
    xbmcplugin.setContent(HANDLE, 'files')
    f = load_filters()
    items = [
        ('Featured', {'mode': 'list', 'query': 'limit=%d&offset=0' % LIMIT, 'title': 'Featured'}),
        ('Female', {'mode': 'list', 'query': 'genders=f&limit=%d&offset=0' % LIMIT, 'title': 'Female'}),
        ('Male', {'mode': 'list', 'query': 'genders=m&limit=%d&offset=0' % LIMIT, 'title': 'Male'}),
        ('Couples', {'mode': 'list', 'query': 'genders=c&limit=%d&offset=0' % LIMIT, 'title': 'Couples'}),
        ('Trans', {'mode': 'list', 'query': 'genders=t&limit=%d&offset=0' % LIMIT, 'title': 'Trans'}),
        ('New cams', {'mode': 'list', 'query': 'new_cams=true&limit=%d&offset=0' % LIMIT, 'title': 'New cams'}),
        ('Top cams', {'mode': 'top'}),
        ('Search...', {'mode': 'search'}),
        ('Filters: %s' % filters_summary(f), {'mode': 'filters', 'back': ''}),
    ]
    followed_label = 'Followed cams (online)'
    if camsite.has_session_cookie():
        try:
            _, total = camsite.api_rooms('enable_recommendations=true&follow=true&limit=1&offline=false&offset=0')
            if total:
                followed_label = 'Followed cams (online) - %d on now' % total
        except Exception:
            pass
    items += [
        (followed_label, {'mode': 'followed', 'offline': 'false'}),
        ('Followed cams (offline)', {'mode': 'followed', 'offline': 'true'}),
        ('Jump back in', {'mode': 'jumpback'}),
        ('My Favorites', {'mode': 'favorites'}),
        ('History', {'mode': 'history'}),
        ('Go to room by name...', {'mode': 'goto'}),
    ]
    if camsite.has_session_cookie():
        items.append(('Log out (%s)' % ADDON.getSetting('username'), {'mode': 'logout'}))
    else:
        items.append(('Log in', {'mode': 'login'}))
    catart = _load_json(CATART_FILE, {})
    for label, params in items:
        li = xbmcgui.ListItem(label=label)
        img = catart.get(label) or catart.get(params.get('title', ''))
        if img:
            li.setArt({'thumb': img, 'icon': img, 'fanart': img})
        folder = params.get('mode') in ('list', 'followed', 'favorites', 'history', 'top', 'filters', 'jumpback')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, folder)
    xbmcplugin.endOfDirectory(HANDLE)


def filters_menu(back):
    xbmcplugin.setContent(HANDLE, 'files')
    f = load_filters()
    back_params = dict(parse_qsl(back)) if back else {}
    rows = [
        ('Region: %s' % dict(REGIONS).get(f['region'], 'Any region'), 'region'),
        ('Age: %s' % (f['age'] or 'Any age'), 'age'),
        ('Tag: %s' % (('#' + f['tag']) if f['tag'] else 'None'), 'tag'),
        ('New cams only: %s' % ('On' if f['new_only'] else 'Off'), 'new_only'),
        ('Sort: %s' % dict(SORTS).get(f['sort'], 'Site order'), 'sort'),
        ('Clear all filters', 'clear'),
    ]
    for label, dim in rows:
        li = xbmcgui.ListItem(label=label)
        params = {'mode': 'setfilter', 'dim': dim, 'back': back}
        if back_params.get('query'):
            q = dict(parse_qsl(back_params['query']))
            if q.get('genders'):
                params['g'] = q['genders']
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url(params), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def tags_view(g, page, back):
    xbmcplugin.setContent(HANDLE, 'files')
    try:
        tags, last = camsite.api_tags(g, page)
    except Exception as e:
        notify('Could not load tags: %s' % e)
        tags, last = [], page
    for t in tags:
        name = t.get('hashtag', '')
        if not name:
            continue
        label = name
        cnt = t.get('room_count') or t.get('count') or t.get('num_rooms')
        if cnt:
            label = '%s  (%s)' % (name, cnt)
        li = xbmcgui.ListItem(label=label)
        tops = t.get('top_rooms') or []
        if tops and tops[0].get('img'):
            li.setArt({'thumb': tops[0]['img'], 'icon': tops[0]['img']})
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'settag', 'tag': name, 'back': back}), li, False)
    if page < last:
        li = xbmcgui.ListItem(label='Next page >>')
        xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'tags', 'g': g, 'page': str(page + 1), 'back': back}), li, True)
    xbmcplugin.endOfDirectory(HANDLE)


def top_view():
    # Measured shape (2026-11-13): {top: [{room_slug, room_user, points,
    # viewers, image_url}], ...} - the hourly contest leaders.
    xbmcplugin.setContent(HANDLE, 'videos')
    entries = []
    try:
        entries = camsite.api_leaderboard().get('top', []) or []
    except Exception as e:
        notify('Top cams unavailable: %s' % e)
    favs = fav_slugs()
    shown = 0
    for ent in entries:
        slug = ent.get('room_slug') or ent.get('room_user')
        if not slug:
            continue
        room = {'username': slug,
                'img': ent.get('image_url', ''),
                'num_users': ent.get('viewers', 0),
                'num_followers': 0,
                'room_subject': 'Top cam - %s contest points' % ent.get('points', ''),
                'current_show': 'public',
                'tags': []}
        add_room(room, favs)
        shown += 1
    if not shown:
        li = xbmcgui.ListItem(label='Top cams unavailable right now')
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def search_view():
    kb = xbmcgui.Dialog().input('Search rooms', type=xbmcgui.INPUT_ALPHANUM)
    if not kb:
        return
    term = kb.strip()
    if not term:
        return
    # Measured 2026-11-13: the room-list API IGNORES a keywords parameter (it
    # returns the standard list). Real search here = tag match first, then a
    # client-side scan of the live lists for name/subject/tag matches.
    xbmcplugin.setContent(HANDLE, 'videos')
    rooms = []
    low = term.lower()
    if ' ' not in term:
        try:
            rooms, _ = camsite.api_rooms('hashtags=%s&limit=%d&offset=0' % (quote(low), LIMIT))
        except Exception:
            rooms = []
    if not rooms:
        seen = set()
        try:
            for page in range(5):
                batch, _ = camsite.api_rooms('limit=%d&offset=%d' % (LIMIT, page * LIMIT))
                if not batch:
                    break
                for r in batch:
                    slug = r.get('username', '')
                    hay = (slug + ' ' + (r.get('room_subject') or '') + ' ' +
                           ' '.join(r.get('tags') or [])).lower()
                    if low in hay and slug not in seen:
                        seen.add(slug)
                        rooms.append(r)
        except Exception:
            pass
    favs = fav_slugs()
    for room in rooms[:LIMIT]:
        add_room(room, favs)
    if not rooms:
        li = xbmcgui.ListItem(label='No rooms found for "%s"' % term)
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def followed_view(offline):
    if not ensure_login():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    list_rooms(camsite.followed_query(offline == 'true'), 'Followed', filtered=False)


def _status_items(entries, kind):
    xbmcplugin.setContent(HANDLE, 'videos')
    if not entries:
        label = ('No favorites yet - use the context menu on a room' if kind == 'favorites'
                 else 'Nothing here yet - rooms you watch will land here' if kind == 'jumpback'
                 else 'No history yet')
        li = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
    favs = fav_slugs()
    for ent in entries:
        slug = ent.get('slug', '')
        img = ent.get('img', '')
        if not slug:
            continue
        try:
            _, status = camsite.resolve_stream(slug)
        except Exception:
            status = 'unknown'
        li = xbmcgui.ListItem(label=slug + '  [' + status + ']')
        li.setArt({'thumb': img, 'icon': img, 'fanart': img})
        li.setInfo('video', {'title': slug, 'plot': 'Status: ' + status, 'mediatype': 'video'})
        if kind == 'favorites':
            menu = [('Remove from My Favorites', 'RunPlugin(%s)' % plugin_url({'mode': 'fav_del', 'slug': slug}))]
        else:
            menu = [('Remove from History', 'RunPlugin(%s)' % plugin_url({'mode': 'hist_del', 'slug': slug}))]
        li.addContextMenuItems(menu)
        if status == 'public':
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'play', 'slug': slug, 'img': img}), li, False)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url({'mode': 'offline', 'slug': slug, 'status': status}), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def favorites_view():
    _status_items(load_favs(), 'favorites')


def history_view():
    _status_items(_load_json(HIST_FILE, []), 'history')


def jumpback_view():
    _status_items(_load_json(HIST_FILE, [])[:14], 'jumpback')


def _flag(path):
    return _load_json(path, {}).get('enabled') is True


def inroom():
    """The in-room panel (Fire remote Menu key): everything dynamic lives
    here — surfing, chat, room info, star — never in Configure."""
    ctx = zaputil.load_context(ZAP_FILE)
    slug = ctx.get('slug', '')
    try:
        playing = xbmc.Player().getPlayingFile() or ''
    except Exception:
        playing = ''
    slug = chatclient.slug_from_playing_file(playing) or slug
    if not slug:
        return
    chat_on = _flag(CHAT_STATE_FILE)
    info_on = _flag(INFO_STATE_FILE)
    starred = slug in fav_slugs()
    opts = ['Next room', 'Previous room',
            'Chat: %s' % ('ON — tap to turn off' if chat_on else 'off — tap to turn on'),
            'Room info: %s' % ('ON — tap to turn off' if info_on else 'off — tap to turn on'),
            ('Remove from favorites' if starred else 'Add to favorites (joins the online set)')]
    pick = xbmcgui.Dialog().select(slug, opts)
    if pick == 0:
        zap(1)
    elif pick == 1:
        zap(-1)
    elif pick == 2:
        _save_json(CHAT_STATE_FILE, {'enabled': not chat_on})
    elif pick == 3:
        _save_json(INFO_STATE_FILE, {'enabled': not info_on})
    elif pick == 4:
        if starred:
            _save_json(FAV_FILE, [f for f in load_favs() if f.get('slug') != slug])
            notify('Removed ' + slug + ' from My Favorites')
        else:
            favs = load_favs()
            favs.append({'slug': slug, 'img': ''})
            _save_json(FAV_FILE, favs)
            if camsite.has_session_cookie():
                try:
                    camsite.follow_action(slug, True)
                except Exception:
                    pass
            notify('Added ' + slug + ' to My Favorites')


def chat_enabled_state():
    st = _load_json(CHAT_STATE_FILE, {})
    return st.get('enabled') is True


def zap(direction):
    """Channel-surf. Only acts when OUR stream is playing; otherwise the
    key is handed back to Kodi untouched (PVR keeps its channel keys)."""
    try:
        playing = xbmc.Player().getPlayingFile() or ''
    except Exception:
        playing = ''
    current = chatclient.slug_from_playing_file(playing)
    if not current:
        xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Input.ExecuteAction',
            'params': {'action': 'channeldown' if direction >= 0 else 'channelup'}}))
        return
    source = ADDON.getSetting('zap_source') or 'list'
    ctx = zaputil.load_context(ZAP_FILE)
    back = ctx.get('back', '')
    target = None
    if source == 'favorites':
        live = []
        for ent in load_favs()[:25]:
            try:
                _, st = camsite.resolve_stream(ent.get('slug', ''))
                if st == 'public':
                    live.append(ent['slug'])
            except Exception:
                pass
        target = zaputil.step(live, current, direction)
    elif source in ('category', 'search', 'wild'):
        query = ''
        if source != 'wild' and back:
            query = dict(parse_qsl(back)).get('query', '')
        if not query:
            query = 'limit=90&offset=0'
        q = dict(parse_qsl(query))
        q['limit'] = '90'
        try:
            _, total = camsite.api_rooms(urlencode(dict(q, offset='0', limit='1')))
        except Exception:
            total = 0
        import random as _r
        q['offset'] = str(_r.randrange(0, max(total - 90, 1)) if total > 90 else 0)
        try:
            rooms, _ = camsite.api_rooms(urlencode(q))
        except Exception:
            rooms = []
        target = zaputil.random_pick(zaputil.public_slugs(rooms), current)
    else:
        q = dict(parse_qsl(dict(parse_qsl(back)).get('query', ''))) if back else {}
        limit = int(q.get('limit', str(LIMIT)))
        off0 = int(q.get('offset', '0'))
        slugs = []
        for off in (off0, off0 + limit, off0 - limit):
            if off < 0:
                continue
            qq = dict(q, offset=str(off), limit=str(limit))
            try:
                rooms, _ = camsite.api_rooms(urlencode(qq))
            except Exception:
                rooms = []
            slugs = zaputil.public_slugs(rooms)
            if current in slugs:
                break
        target = zaputil.step(slugs, current, direction)
    if target and target != current:
        xbmc.Player().play(plugin_url({'mode': 'play', 'slug': target, 'img': '', 'ctx': back}))


def relay_alive():
    try:
        with urlopen('http://127.0.0.1:%d/ping' % relaymod.PORT, timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def play(slug, img='', ctx=''):
    try:
        url, status = camsite.resolve_stream(slug)
    except Exception as e:
        notify('Could not resolve the stream: %s' % e)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if status != 'public' or not url:
        notify('%s is not in a public show right now (%s)' % (slug, status))
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not relay_alive():
        notify('The stream relay is not running - restart Kodi once after installing this update')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    record_history(slug, img)
    zaputil.save_context(ZAP_FILE, ctx, slug)
    li = xbmcgui.ListItem(path=relaymod.play_url(slug))
    li.setInfo('video', {'title': slug})
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    # Play HLS through InputStream Adaptive, not Kodi's built-in demuxer:
    # the working add-ons for this site all route playback through IA, whose
    # HLS engine rides the live edge instead of declaring EOF on it.
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def _go_back(back):
    if back:
        xbmc.executebuiltin('Container.Update(%s)' % plugin_url(dict(parse_qsl(back))))
    else:
        xbmc.executebuiltin('Container.Update(%s)' % plugin_url({'mode': 'filters', 'back': back}))


def set_filter(dim, back, g=''):
    f = load_filters()
    dlg = xbmcgui.Dialog()
    if dim == 'region':
        labels = [lbl for _, lbl in REGIONS]
        i = dlg.select('Region', labels)
        if i >= 0:
            f['region'] = REGIONS[i][0]
    elif dim == 'age':
        labels = [lbl for _, lbl in AGES]
        i = dlg.select('Age', labels)
        if i >= 0:
            f['age'] = AGES[i][0]
    elif dim == 'sort':
        labels = [lbl for _, lbl in SORTS]
        i = dlg.select('Sort', labels)
        if i >= 0:
            f['sort'] = SORTS[i][0]
    elif dim == 'new_only':
        f['new_only'] = not f['new_only']
    elif dim == 'clear':
        f = {'region': '', 'age': '', 'tag': '', 'new_only': False, 'sort': ''}
    elif dim == 'tag':
        # bounce to the tag picker for this context's gender
        xbmc.executebuiltin('Container.Update(%s)' % plugin_url({'mode': 'tags', 'g': g, 'page': '1', 'back': back}))
        return
    save_filters(f)
    _go_back(back)


def set_tag(tag, back):
    f = load_filters()
    f['tag'] = tag
    save_filters(f)
    notify('Filter set: #%s' % tag)
    _go_back(back)


# ---------------- routing ----------------

def main():
    mode = PARAMS.get('mode', '')
    if mode == 'list':
        list_rooms(PARAMS.get('query', 'limit=%d&offset=0' % LIMIT), PARAMS.get('title', ''))
    elif mode == 'followed':
        followed_view(PARAMS.get('offline', 'false'))
    elif mode == 'favorites':
        favorites_view()
    elif mode == 'history':
        history_view()
    elif mode == 'top':
        top_view()
    elif mode == 'search':
        search_view()
    elif mode == 'filters':
        filters_menu(PARAMS.get('back', ''))
    elif mode == 'setfilter':
        set_filter(PARAMS.get('dim', ''), PARAMS.get('back', ''), PARAMS.get('g', ''))
    elif mode == 'tags':
        tags_view(PARAMS.get('g', ''), int(PARAMS.get('page', '1')), PARAMS.get('back', ''))
    elif mode == 'settag':
        set_tag(PARAMS.get('tag', ''), PARAMS.get('back', ''))
    elif mode == 'play':
        play(PARAMS.get('slug', ''), PARAMS.get('img', ''), PARAMS.get('ctx', ''))
    elif mode == 'zap':
        zap(1 if PARAMS.get('dir') != 'prev' else -1)
    elif mode == 'chattoggle':
        enabled = not chat_enabled_state()
        _save_json(CHAT_STATE_FILE, {'enabled': enabled})
        notify('Chat overlay %s' % ('on' if enabled else 'off'))
    elif mode == 'inroom':
        inroom()
    elif mode == 'jumpback':
        jumpback_view()
    elif mode == 'offline':
        notify('%s is %s right now' % (PARAMS.get('slug', ''), PARAMS.get('status', 'offline')))
    elif mode == 'goto':
        kb = xbmcgui.Dialog().input('Room name', type=xbmcgui.INPUT_ALPHANUM)
        if kb:
            xbmc.executebuiltin('PlayMedia(%s)' % plugin_url({'mode': 'play', 'slug': kb.strip().lower()}))
    elif mode == 'login':
        ok, msg = (True, 'Already logged in') if (camsite.has_session_cookie() and camsite.logged_in_live()) else \
            camsite.do_login(ADDON.getSetting('username').strip(), ADDON.getSetting('password'))
        notify(msg)
        if not ok and 'settings first' in msg:
            ADDON.openSettings()
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'logout':
        try:
            camsite.http(camsite.SITE + '/auth/logout/')
        except Exception:
            pass
        camsite.clear_session()
        notify('Logged out')
        xbmc.executebuiltin('Container.Refresh')
    elif mode in ('follow', 'unfollow'):
        if ensure_login():
            ok, msg = camsite.follow_action(PARAMS.get('slug', ''), mode == 'follow')
            notify(msg)
            if ok:
                xbmc.executebuiltin('Container.Refresh')
    elif mode == 'fav_add':
        favs = load_favs()
        slug = PARAMS.get('slug', '')
        if slug and slug not in fav_slugs():
            favs.append({'slug': slug, 'img': PARAMS.get('img', '')})
            _save_json(FAV_FILE, favs)
            # A star joins the online set too: follow on the account so the
            # room shows in Followed (online) and gets alert coverage.
            if camsite.has_session_cookie():
                try:
                    camsite.follow_action(slug, True)
                except Exception:
                    pass
            notify('Added ' + slug + ' to My Favorites')
    elif mode == 'fav_del':
        slug = PARAMS.get('slug', '')
        _save_json(FAV_FILE, [f for f in load_favs() if f.get('slug') != slug])
        notify('Removed ' + slug + ' from My Favorites')
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'hist_del':
        slug = PARAMS.get('slug', '')
        _save_json(HIST_FILE, [h for h in _load_json(HIST_FILE, []) if h.get('slug') != slug])
        xbmc.executebuiltin('Container.Refresh')
    else:
        root_menu()


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        # A directory must never die silently (the 04:07 root failure class):
        # render the error as an item instead of raising.
        try:
            notify('Something failed: %s' % e)
            li = xbmcgui.ListItem(label='Error: %s' % e)
            xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass
