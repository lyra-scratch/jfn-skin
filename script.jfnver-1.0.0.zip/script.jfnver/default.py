import xbmc, xbmcgui
lines = []
for label in ['System.BuildVersion', 'System.BuildVersionCode', 'System.FriendlyName']:
    try:
        lines.append(label + ' = ' + xbmc.getInfoLabel(label))
    except Exception as e:
        lines.append(label + ' ERROR ' + str(e))
with open('/storage/emulated/0/Download/buildversion.txt', 'w') as f:
    f.write('\n'.join(lines))
xbmcgui.Dialog().notification('JFN Version Probe', lines[0], xbmcgui.NOTIFICATION_INFO, 6000)
