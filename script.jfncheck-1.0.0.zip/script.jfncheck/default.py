import os, time
import xbmc, xbmcvfs

HOME = xbmcvfs.translatePath('special://home/')
DL = '/storage/emulated/0/Download'
SNAP = os.path.join(DL, 'jfn-clone')
STATUS = os.path.join(DL, 'jfn-check-status.txt')
REPORT = os.path.join(DL, 'jfn-check-report.txt')

def status(msg):
    try:
        with open(STATUS, 'a') as f:
            f.write('%s %s\n' % (time.strftime('%H:%M:%S'), msg))
            f.flush()
    except Exception:
        pass
    xbmc.log('JFNCHECK: ' + msg, xbmc.LOGINFO)

def measure(base):
    # returns files, bytes, dirs, errors using scandir recursion with
    # visible error counting (os.walk hides listing failures; scandir
    # with an explicit try does not)
    files = 0; byt = 0; dirs = 0; errs = 0
    stack = [base]
    while stack:
        cur = stack.pop()
        try:
            it = os.scandir(cur)
        except Exception:
            errs += 1
            continue
        with it:
            for entry in it:
                try:
                    if entry.is_dir(follow_symlinks=False):
                        dirs += 1
                        stack.append(entry.path)
                    elif entry.is_file(follow_symlinks=False):
                        files += 1
                        try:
                            byt += entry.stat(follow_symlinks=False).st_size
                        except Exception:
                            errs += 1
                    else:
                        files += 1
                except Exception:
                    errs += 1
    return files, byt, dirs, errs

def measure_top(tree_base, top, out):
    base = os.path.join(tree_base, top)
    if not os.path.isdir(base):
        out.append('MISSING-TREE %s' % base)
        return 0, 0, 0, 0
    tf = tb = td = te = 0
    try:
        names = sorted(os.listdir(base))
    except Exception as e:
        out.append('LIST-FAILED %s %r' % (base, e))
        return 0, 0, 0, 1
    for name in names:
        p = os.path.join(base, name)
        if os.path.isdir(p):
            f, b, d, e = measure(p)
            out.append('FOLDER %s %s files=%d bytes=%d dirs=%d errors=%d' % (top, name, f, b, d, e))
            tf += f; tb += b; td += d; te += e
        else:
            try:
                sz = os.path.getsize(p)
            except Exception:
                sz = -1; te += 1
            out.append('FILE %s %s bytes=%d' % (top, name, sz))
            tf += 1; tb += max(sz, 0)
    out.append('TOTAL %s files=%d bytes=%d dirs=%d errors=%d' % (top, tf, tb, td, te))
    return tf, tb, td, te

try:
    with open(STATUS, 'w') as f:
        f.write('')
    status('CHECK START home=%s' % HOME)
    lines = []
    for label, tree in (('SNAPSHOT', SNAP), ('KODIHOME', HOME)):
        for top in ('addons', 'userdata'):
            status('%s %s: measuring' % (label, top))
            sec = ['== %s %s ==' % (label, top)]
            measure_top(tree, top, sec)
            lines.extend(sec)
            status('%s %s: done' % (label, top))
    with open(REPORT, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    status('CHECK DONE')
except Exception as e:
    status('FAILED: %r' % (e,))
