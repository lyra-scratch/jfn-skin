import os, shutil, time
import xbmc, xbmcvfs

HOME = xbmcvfs.translatePath('special://home/')
DL = '/storage/emulated/0/Download'
SNAP = os.path.join(DL, 'jfn-clone')
STATUS = os.path.join(DL, 'jfn-restore-status.txt')

def status(msg):
    try:
        with open(STATUS, 'a') as f:
            f.write('%s %s\n' % (time.strftime('%H:%M:%S'), msg))
            f.flush()
    except Exception:
        pass
    xbmc.log('JFNRESTORE: ' + msg, xbmc.LOGINFO)

def copy_top(top):
    srcdir = os.path.join(SNAP, top)
    dest_top = os.path.join(HOME, top)
    if not os.path.isdir(srcdir):
        status('%s: SOURCE MISSING, skipped' % top)
        return 0, 0, 0
    status('%s: start' % top)
    files = 0; byt = 0; errs = 0
    for root, dirs, names in os.walk(srcdir):
        rel = os.path.relpath(root, srcdir)
        destdir = dest_top if rel == '.' else os.path.join(dest_top, rel)
        try:
            os.makedirs(destdir, exist_ok=True)
        except Exception:
            pass
        for fn in names:
            sp = os.path.join(root, fn)
            dp = os.path.join(destdir, fn)
            try:
                if os.path.exists(dp):
                    try:
                        os.chmod(dp, 0o644)
                    except Exception:
                        pass
                shutil.copyfile(sp, dp)
                files += 1
                byt += os.path.getsize(dp)
            except Exception:
                errs += 1
            if files and files % 200 == 0:
                status('%s: %d files, %d bytes, %d errors' % (top, files, byt, errs))
    status('%s: COMPLETE %d files, %d bytes, %d errors' % (top, files, byt, errs))
    return files, byt, errs

try:
    with open(STATUS, 'w') as f:
        f.write('')
    status('RESTORE START home=%s' % HOME)
    tf = tb = te = 0
    for top in ('addons', 'userdata'):
        f_, b_, e_ = copy_top(top)
        tf += f_; tb += b_; te += e_
    status('RESTORE DONE files=%d bytes=%d errors=%d' % (tf, tb, te))
except Exception as e:
    status('FAILED: %r' % (e,))
